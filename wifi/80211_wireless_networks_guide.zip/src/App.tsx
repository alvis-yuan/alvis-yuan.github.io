import { useState, useEffect, useRef, useCallback } from 'react';

const chapters = [
  {
    id: 'preface',
    group: '前言',
    title: '前言：无线的可能性',
    shortTitle: '前言',
  },
  {
    id: 'ch1',
    group: '第一部分：基础概念',
    title: '第1章：无线网络简介',
    shortTitle: '第1章',
  },
  {
    id: 'ch2',
    group: '第一部分：基础概念',
    title: '第2章：802.11 网络概览',
    shortTitle: '第2章',
  },
  {
    id: 'ch3',
    group: '第二部分：MAC 层',
    title: '第3章：802.11 MAC 基础',
    shortTitle: '第3章',
  },
  {
    id: 'ch4',
    group: '第二部分：MAC 层',
    title: '第4章：802.11 帧详解',
    shortTitle: '第4章',
  },
  {
    id: 'ch5',
    group: '第三部分：安全',
    title: '第5章：有线等效保密（WEP）',
    shortTitle: '第5章',
  },
  {
    id: 'ch6',
    group: '第三部分：安全',
    title: '第6章：802.1X 用户认证',
    shortTitle: '第6章',
  },
  {
    id: 'ch7',
    group: '第三部分：安全',
    title: '第7章：802.11i：RSN、TKIP 与 CCMP',
    shortTitle: '第7章',
  },
  {
    id: 'ch8',
    group: '第四部分：管理与服务',
    title: '第8章：管理操作',
    shortTitle: '第8章',
  },
  {
    id: 'ch9',
    group: '第四部分：管理与服务',
    title: '第9章：无竞争服务与 PCF',
    shortTitle: '第9章',
  },
  {
    id: 'ch10',
    group: '第五部分：物理层',
    title: '第10章：物理层概览',
    shortTitle: '第10章',
  },
  {
    id: 'ch11',
    group: '第五部分：物理层',
    title: '第11章：跳频（FH）物理层',
    shortTitle: '第11章',
  },
  {
    id: 'ch12',
    group: '第五部分：物理层',
    title: '第12章：直接序列物理层（DSSS/802.11b）',
    shortTitle: '第12章',
  },
  {
    id: 'ch13',
    group: '第五部分：物理层',
    title: '第13章：802.11a/j：5GHz OFDM 物理层',
    shortTitle: '第13章',
  },
  {
    id: 'ch14',
    group: '第五部分：物理层',
    title: '第14章：802.11g：扩展速率物理层（ERP）',
    shortTitle: '第14章',
  },
  {
    id: 'ch15',
    group: '第五部分：物理层',
    title: '第15章：前瞻 802.11n：MIMO-OFDM',
    shortTitle: '第15章',
  },
  {
    id: 'ch16',
    group: '第六部分：部署与运维',
    title: '第16章：802.11 硬件',
    shortTitle: '第16章',
  },
  {
    id: 'ch17',
    group: '第六部分：部署与运维',
    title: '第17章：在 Windows 上使用 802.11',
    shortTitle: '第17章',
  },
  {
    id: 'ch18',
    group: '第六部分：部署与运维',
    title: '第18章：在 macOS 上使用 802.11',
    shortTitle: '第18章',
  },
  {
    id: 'ch19',
    group: '第六部分：部署与运维',
    title: '第19章：在 Linux 上使用 802.11',
    shortTitle: '第19章',
  },
  {
    id: 'ch20',
    group: '第六部分：部署与运维',
    title: '第20章：使用 802.11 接入点',
    shortTitle: '第20章',
  },
  {
    id: 'ch21',
    group: '第六部分：部署与运维',
    title: '第21章：逻辑无线网络架构',
    shortTitle: '第21章',
  },
  {
    id: 'ch22',
    group: '第六部分：部署与运维',
    title: '第22章：安全架构',
    shortTitle: '第22章',
  },
  {
    id: 'ch23',
    group: '第六部分：部署与运维',
    title: '第23章：站点规划与项目管理',
    shortTitle: '第23章',
  },
  {
    id: 'ch24',
    group: '第六部分：部署与运维',
    title: '第24章：802.11 网络分析',
    shortTitle: '第24章',
  },
  {
    id: 'ch25',
    group: '第六部分：部署与运维',
    title: '第25章：802.11 性能调优',
    shortTitle: '第25章',
  },
  {
    id: 'summary',
    group: '总结',
    title: '第一性原理总结',
    shortTitle: '总结',
  },
];

// SVG diagrams
const NetworkArchSVG = () => (
  <svg viewBox="0 0 600 320" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 320 }}>
    <defs>
      <marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0,0 L0,6 L8,3 z" fill="#6366f1" />
      </marker>
    </defs>
    {/* Internet Cloud */}
    <ellipse cx="300" cy="40" rx="80" ry="28" fill="#e0e7ff" stroke="#6366f1" strokeWidth="2" />
    <text x="300" y="45" textAnchor="middle" fontSize="13" fill="#3730a3" fontWeight="bold">互联网 / Internet</text>
    {/* DS Line */}
    <line x1="300" y1="68" x2="300" y2="100" stroke="#6366f1" strokeWidth="2" markerEnd="url(#arrow)" />
    {/* DS Box */}
    <rect x="180" y="100" width="240" height="36" rx="8" fill="#c7d2fe" stroke="#6366f1" strokeWidth="2" />
    <text x="300" y="122" textAnchor="middle" fontSize="13" fill="#3730a3" fontWeight="bold">分布式系统 (DS)</text>
    {/* Lines to APs */}
    <line x1="220" y1="136" x2="140" y2="180" stroke="#6366f1" strokeWidth="2" />
    <line x1="380" y1="136" x2="460" y2="180" stroke="#6366f1" strokeWidth="2" />
    {/* AP Left */}
    <rect x="80" y="180" width="120" height="36" rx="8" fill="#818cf8" stroke="#4338ca" strokeWidth="2" />
    <text x="140" y="202" textAnchor="middle" fontSize="12" fill="white" fontWeight="bold">接入点 AP1</text>
    {/* AP Right */}
    <rect x="400" y="180" width="120" height="36" rx="8" fill="#818cf8" stroke="#4338ca" strokeWidth="2" />
    <text x="460" y="202" textAnchor="middle" fontSize="12" fill="white" fontWeight="bold">接入点 AP2</text>
    {/* BSS bubbles */}
    <ellipse cx="140" cy="270" rx="90" ry="36" fill="#ede9fe" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="6,3" />
    <text x="140" y="265" textAnchor="middle" fontSize="11" fill="#5b21b6">BSS 1</text>
    <ellipse cx="460" cy="270" rx="90" ry="36" fill="#ede9fe" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="6,3" />
    <text x="460" y="265" textAnchor="middle" fontSize="11" fill="#5b21b6">BSS 2</text>
    {/* Stations */}
    <circle cx="100" cy="278" r="14" fill="#a5b4fc" stroke="#4338ca" strokeWidth="2" />
    <text x="100" y="283" textAnchor="middle" fontSize="10" fill="#1e1b4b">STA</text>
    <circle cx="175" cy="278" r="14" fill="#a5b4fc" stroke="#4338ca" strokeWidth="2" />
    <text x="175" y="283" textAnchor="middle" fontSize="10" fill="#1e1b4b">STA</text>
    <circle cx="420" cy="278" r="14" fill="#a5b4fc" stroke="#4338ca" strokeWidth="2" />
    <text x="420" y="283" textAnchor="middle" fontSize="10" fill="#1e1b4b">STA</text>
    <circle cx="500" cy="278" r="14" fill="#a5b4fc" stroke="#4338ca" strokeWidth="2" />
    <text x="500" y="283" textAnchor="middle" fontSize="10" fill="#1e1b4b">STA</text>
    {/* Lines from APs to stations */}
    <line x1="140" y1="216" x2="100" y2="264" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="4,2" />
    <line x1="140" y1="216" x2="175" y2="264" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="4,2" />
    <line x1="460" y1="216" x2="420" y2="264" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="4,2" />
    <line x1="460" y1="216" x2="500" y2="264" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="4,2" />
    {/* ESS label */}
    <rect x="10" y="5" width="580" height="305" rx="14" fill="none" stroke="#c7d2fe" strokeWidth="2" strokeDasharray="8,4" />
    <text x="30" y="20" fontSize="11" fill="#6366f1" fontStyle="italic">扩展服务集 ESS</text>
  </svg>
);

const DCFFlowSVG = () => (
  <svg viewBox="0 0 560 360" className="w-full max-w-xl mx-auto" style={{ maxHeight: 360 }}>
    <defs>
      <marker id="arr2" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0,0 L0,6 L8,3 z" fill="#059669" />
      </marker>
    </defs>
    {/* Title */}
    <text x="280" y="22" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#065f46">DCF / CSMA-CA 访问流程</text>
    {/* Start */}
    <ellipse cx="280" cy="52" rx="60" ry="20" fill="#d1fae5" stroke="#059669" strokeWidth="2" />
    <text x="280" y="57" textAnchor="middle" fontSize="12" fill="#065f46">有数据发送</text>
    <line x1="280" y1="72" x2="280" y2="96" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    {/* Check idle */}
    <polygon points="280,100 360,130 280,160 200,130" fill="#ecfdf5" stroke="#059669" strokeWidth="2" />
    <text x="280" y="127" textAnchor="middle" fontSize="11" fill="#065f46">信道空闲?</text>
    <text x="280" y="142" textAnchor="middle" fontSize="10" fill="#047857">(DIFS)</text>
    {/* Yes path */}
    <line x1="360" y1="130" x2="420" y2="130" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    <text x="390" y="122" textAnchor="middle" fontSize="10" fill="#059669">是</text>
    <rect x="420" y="114" width="100" height="32" rx="8" fill="#d1fae5" stroke="#059669" strokeWidth="2" />
    <text x="470" y="134" textAnchor="middle" fontSize="11" fill="#065f46">直接发送</text>
    {/* No path */}
    <line x1="280" y1="160" x2="280" y2="195" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    <text x="258" y="180" textAnchor="middle" fontSize="10" fill="#059669">否</text>
    <rect x="200" y="195" width="160" height="32" rx="8" fill="#d1fae5" stroke="#059669" strokeWidth="2" />
    <text x="280" y="215" textAnchor="middle" fontSize="11" fill="#065f46">随机退避 (Backoff)</text>
    <line x1="280" y1="227" x2="280" y2="257" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    <polygon points="280,260 360,290 280,320 200,290" fill="#ecfdf5" stroke="#059669" strokeWidth="2" />
    <text x="280" y="287" textAnchor="middle" fontSize="11" fill="#065f46">退避计数器</text>
    <text x="280" y="302" textAnchor="middle" fontSize="10" fill="#047857">归零?</text>
    {/* Yes */}
    <line x1="360" y1="290" x2="420" y2="290" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    <text x="390" y="282" textAnchor="middle" fontSize="10" fill="#059669">是</text>
    <rect x="420" y="274" width="100" height="32" rx="8" fill="#d1fae5" stroke="#059669" strokeWidth="2" />
    <text x="470" y="294" textAnchor="middle" fontSize="11" fill="#065f46">发送帧</text>
    {/* No loop */}
    <line x1="200" y1="290" x2="140" y2="290" stroke="#059669" strokeWidth="2" />
    <line x1="140" y1="290" x2="140" y2="195" stroke="#059669" strokeWidth="2" />
    <line x1="140" y1="195" x2="200" y2="195" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    <text x="115" y="244" textAnchor="middle" fontSize="10" fill="#059669" transform="rotate(-90,115,244)">信道忙,等待</text>
    {/* ACK */}
    <line x1="470" y1="146" x2="470" y2="272" stroke="#059669" strokeWidth="1.5" strokeDasharray="5,3" />
    <line x1="420" y1="306" x2="360" y2="340" stroke="#059669" strokeWidth="2" markerEnd="url(#arr2)" />
    <rect x="230" y="332" width="130" height="28" rx="8" fill="#a7f3d0" stroke="#059669" strokeWidth="2" />
    <text x="295" y="350" textAnchor="middle" fontSize="11" fill="#065f46">等待 ACK 确认</text>
  </svg>
);

const FrameFormatSVG = () => (
  <svg viewBox="0 0 640 200" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 200 }}>
    <text x="320" y="20" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#1e40af">802.11 帧格式</text>
    {/* Frame Control */}
    <rect x="10" y="35" width="90" height="50" fill="#dbeafe" stroke="#1d4ed8" strokeWidth="2" />
    <text x="55" y="57" textAnchor="middle" fontSize="10" fill="#1e40af" fontWeight="bold">Frame</text>
    <text x="55" y="70" textAnchor="middle" fontSize="10" fill="#1e40af" fontWeight="bold">Control</text>
    <text x="55" y="83" textAnchor="middle" fontSize="9" fill="#3b82f6">2 字节</text>
    {/* Duration */}
    <rect x="102" y="35" width="70" height="50" fill="#ede9fe" stroke="#7c3aed" strokeWidth="2" />
    <text x="137" y="57" textAnchor="middle" fontSize="10" fill="#5b21b6" fontWeight="bold">Duration</text>
    <text x="137" y="70" textAnchor="middle" fontSize="10" fill="#5b21b6" fontWeight="bold">/ID</text>
    <text x="137" y="83" textAnchor="middle" fontSize="9" fill="#7c3aed">2 字节</text>
    {/* Address 1-4 */}
    <rect x="174" y="35" width="70" height="50" fill="#fce7f3" stroke="#be185d" strokeWidth="2" />
    <text x="209" y="62" textAnchor="middle" fontSize="10" fill="#9d174d" fontWeight="bold">地址1</text>
    <text x="209" y="77" textAnchor="middle" fontSize="9" fill="#be185d">6 字节</text>
    <rect x="246" y="35" width="70" height="50" fill="#fce7f3" stroke="#be185d" strokeWidth="2" />
    <text x="281" y="62" textAnchor="middle" fontSize="10" fill="#9d174d" fontWeight="bold">地址2</text>
    <text x="281" y="77" textAnchor="middle" fontSize="9" fill="#be185d">6 字节</text>
    <rect x="318" y="35" width="70" height="50" fill="#fce7f3" stroke="#be185d" strokeWidth="2" />
    <text x="353" y="62" textAnchor="middle" fontSize="10" fill="#9d174d" fontWeight="bold">地址3</text>
    <text x="353" y="77" textAnchor="middle" fontSize="9" fill="#be185d">6 字节</text>
    {/* Seq Control */}
    <rect x="390" y="35" width="70" height="50" fill="#ecfdf5" stroke="#059669" strokeWidth="2" />
    <text x="425" y="57" textAnchor="middle" fontSize="10" fill="#065f46" fontWeight="bold">Sequence</text>
    <text x="425" y="70" textAnchor="middle" fontSize="10" fill="#065f46" fontWeight="bold">Control</text>
    <text x="425" y="83" textAnchor="middle" fontSize="9" fill="#059669">2 字节</text>
    {/* Address 4 */}
    <rect x="462" y="35" width="60" height="50" fill="#fce7f3" stroke="#be185d" strokeWidth="2" strokeDasharray="4,2" />
    <text x="492" y="62" textAnchor="middle" fontSize="10" fill="#9d174d" fontWeight="bold">地址4</text>
    <text x="492" y="77" textAnchor="middle" fontSize="9" fill="#be185d">可选</text>
    {/* Frame Body */}
    <rect x="524" y="35" width="62" height="50" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
    <text x="555" y="57" textAnchor="middle" fontSize="10" fill="#92400e" fontWeight="bold">帧体</text>
    <text x="555" y="70" textAnchor="middle" fontSize="9" fill="#b45309">Frame</text>
    <text x="555" y="83" textAnchor="middle" fontSize="9" fill="#b45309">Body</text>
    {/* FCS */}
    <rect x="588" y="35" width="42" height="50" fill="#fee2e2" stroke="#dc2626" strokeWidth="2" />
    <text x="609" y="60" textAnchor="middle" fontSize="10" fill="#991b1b" fontWeight="bold">FCS</text>
    <text x="609" y="75" textAnchor="middle" fontSize="9" fill="#dc2626">4字节</text>
    {/* Labels */}
    <text x="320" y="115" textAnchor="middle" fontSize="11" fill="#374151" fontStyle="italic">
      802.11 通用帧格式 — 包含至多4个MAC地址字段（WDS模式）
    </text>
    {/* Frame Control breakdown */}
    <rect x="10" y="130" width="620" height="55" rx="6" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1.5" />
    <text x="20" y="148" fontSize="11" fontWeight="bold" fill="#334155">Frame Control 字段细分：</text>
    {['协议版本\n2bit','类型\n2bit','子类型\n4bit','To DS\n1','From DS\n1','更多分片\n1','重传\n1','PM\n1','更多数据\n1','WEP\n1','顺序\n1'].map((label, i) => {
      const labels = label.split('\n');
      const x = 20 + i * 56;
      return (
        <g key={i}>
          <rect x={x} y={154} width={52} height={22} fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1" rx="3" />
          <text x={x + 26} y={163} textAnchor="middle" fontSize="8" fill="#334155">{labels[0]}</text>
          <text x={x + 26} y={173} textAnchor="middle" fontSize="8" fill="#64748b">{labels[1] ?? ''}</text>
        </g>
      );
    })}
  </svg>
);

const WEPDiagramSVG = () => (
  <svg viewBox="0 0 600 260" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 260 }}>
    <text x="300" y="22" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#dc2626">WEP 加密流程</text>
    {/* IV + Key */}
    <rect x="20" y="45" width="80" height="35" rx="6" fill="#fee2e2" stroke="#dc2626" strokeWidth="2" />
    <text x="60" y="65" textAnchor="middle" fontSize="11" fill="#991b1b" fontWeight="bold">IV (24位)</text>
    <rect x="20" y="90" width="80" height="35" rx="6" fill="#fee2e2" stroke="#dc2626" strokeWidth="2" />
    <text x="60" y="110" textAnchor="middle" fontSize="11" fill="#991b1b" fontWeight="bold">WEP密钥</text>
    <text x="60" y="123" textAnchor="middle" fontSize="10" fill="#dc2626">(40/104位)</text>
    {/* Arrow to RC4 */}
    <line x1="100" y1="80" x2="160" y2="80" stroke="#dc2626" strokeWidth="2" markerEnd="url(#arrRed)" />
    <defs>
      <marker id="arrRed" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0,0 L0,6 L8,3 z" fill="#dc2626" />
      </marker>
    </defs>
    <rect x="160" y="55" width="100" height="50" rx="8" fill="#fef2f2" stroke="#dc2626" strokeWidth="2" />
    <text x="210" y="78" textAnchor="middle" fontSize="12" fill="#991b1b" fontWeight="bold">RC4</text>
    <text x="210" y="94" textAnchor="middle" fontSize="11" fill="#dc2626">密钥流生成</text>
    {/* Plaintext */}
    <rect x="20" y="155" width="100" height="35" rx="6" fill="#dbeafe" stroke="#1d4ed8" strokeWidth="2" />
    <text x="70" y="178" textAnchor="middle" fontSize="11" fill="#1e40af" fontWeight="bold">明文数据</text>
    {/* XOR */}
    <line x1="210" y1="105" x2="210" y2="155" stroke="#dc2626" strokeWidth="2" markerEnd="url(#arrRed)" />
    <line x1="120" y1="172" x2="175" y2="172" stroke="#1d4ed8" strokeWidth="2" markerEnd="url(#arrRed)" />
    <circle cx="210" cy="172" r="18" fill="#fef9c3" stroke="#ca8a04" strokeWidth="2" />
    <text x="210" y="177" textAnchor="middle" fontSize="16" fill="#92400e" fontWeight="bold">⊕</text>
    {/* Ciphertext */}
    <line x1="228" y1="172" x2="280" y2="172" stroke="#ca8a04" strokeWidth="2" markerEnd="url(#arrRed)" />
    <rect x="280" y="155" width="100" height="35" rx="6" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
    <text x="330" y="178" textAnchor="middle" fontSize="11" fill="#92400e" fontWeight="bold">密文数据</text>
    {/* ICV */}
    <rect x="20" y="210" width="80" height="30" rx="6" fill="#ede9fe" stroke="#7c3aed" strokeWidth="2" />
    <text x="60" y="228" textAnchor="middle" fontSize="11" fill="#5b21b6">ICV(CRC32)</text>
    <line x1="100" y1="225" x2="280" y2="225" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="4,2" />
    <line x1="280" y1="225" x2="280" y2="190" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="4,2" markerEnd="url(#arrRed)" />
    {/* Final frame */}
    <rect x="400" y="130" width="180" height="100" rx="8" fill="#f0fdf4" stroke="#16a34a" strokeWidth="2" />
    <text x="490" y="153" textAnchor="middle" fontSize="12" fill="#15803d" fontWeight="bold">最终加密帧</text>
    <rect x="412" y="162" width="35" height="22" rx="3" fill="#bbf7d0" stroke="#16a34a" strokeWidth="1" />
    <text x="430" y="176" textAnchor="middle" fontSize="9" fill="#166534">IV</text>
    <rect x="450" y="162" width="50" height="22" rx="3" fill="#fef08a" stroke="#ca8a04" strokeWidth="1" />
    <text x="475" y="176" textAnchor="middle" fontSize="9" fill="#92400e">密文</text>
    <rect x="503" y="162" width="40" height="22" rx="3" fill="#e9d5ff" stroke="#7c3aed" strokeWidth="1" />
    <text x="523" y="176" textAnchor="middle" fontSize="9" fill="#6d28d9">ICV</text>
    <text x="490" y="215" textAnchor="middle" fontSize="10" fill="#dc2626" fontStyle="italic">⚠ IV重用导致安全漏洞</text>
    <line x1="380" y1="172" x2="400" y2="172" stroke="#16a34a" strokeWidth="2" markerEnd="url(#arrRed)" />
  </svg>
);

const OFDMDiagramSVG = () => (
  <svg viewBox="0 0 600 240" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 240 }}>
    <text x="300" y="20" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#0369a1">OFDM 子载波频谱图</text>
    {/* Axes */}
    <line x1="40" y1="180" x2="570" y2="180" stroke="#334155" strokeWidth="2" markerEnd="url(#arrBlue)" />
    <line x1="40" y1="30" x2="40" y2="190" stroke="#334155" strokeWidth="2" />
    <defs>
      <marker id="arrBlue" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0,0 L0,6 L8,3 z" fill="#334155" />
      </marker>
    </defs>
    <text x="575" y="184" fontSize="11" fill="#334155">频率</text>
    <text x="44" y="26" fontSize="11" fill="#334155">幅度</text>
    {/* Subcarriers - draw sinc-like curves */}
    {[0,1,2,3,4,5,6,7,8,9,10].map((i) => {
      const cx = 70 + i * 46;
      const colors = ['#818cf8','#6366f1','#4f46e5','#4338ca','#3730a3','#0ea5e9','#3730a3','#4338ca','#4f46e5','#6366f1','#818cf8'];
      return (
        <g key={i}>
          <ellipse cx={cx} cy={130} rx={20} ry={80} fill={colors[i]} fillOpacity="0.18" stroke={colors[i]} strokeWidth="2" />
          <line x1={cx} y1={50} x2={cx} y2={180} stroke={colors[i]} strokeWidth="1.5" strokeDasharray="3,2" opacity="0.5" />
          <circle cx={cx} cy={50} r={4} fill={colors[i]} />
          <text x={cx} y={198} textAnchor="middle" fontSize="9" fill="#475569">f{i+1}</text>
        </g>
      );
    })}
    <text x="300" y="228" textAnchor="middle" fontSize="11" fill="#0369a1" fontStyle="italic">
      各子载波相互正交 — 在其他子载波峰值处幅度为零，频谱效率极高
    </text>
    <rect x="460" y="35" width="120" height="60" rx="6" fill="#f0f9ff" stroke="#0369a1" strokeWidth="1.5" />
    <text x="520" y="53" textAnchor="middle" fontSize="11" fill="#0c4a6e" fontWeight="bold">802.11a/g</text>
    <text x="520" y="68" textAnchor="middle" fontSize="10" fill="#0369a1">52 个子载波</text>
    <text x="520" y="83" textAnchor="middle" fontSize="10" fill="#0369a1">最高 54 Mbps</text>
  </svg>
);

const RSNHandshakeSVG = () => (
  <svg viewBox="0 0 580 310" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 310 }}>
    <text x="290" y="20" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#15803d">802.11i 四次握手（4-Way Handshake）</text>
    {/* Participants */}
    <rect x="40" y="35" width="120" height="30" rx="6" fill="#dcfce7" stroke="#16a34a" strokeWidth="2" />
    <text x="100" y="55" textAnchor="middle" fontSize="12" fill="#15803d" fontWeight="bold">请求方 (STA)</text>
    <rect x="420" y="35" width="120" height="30" rx="6" fill="#dbeafe" stroke="#1d4ed8" strokeWidth="2" />
    <text x="480" y="55" textAnchor="middle" fontSize="12" fill="#1e40af" fontWeight="bold">认证方 (AP)</text>
    {/* Vertical lines */}
    <line x1="100" y1="65" x2="100" y2="290" stroke="#16a34a" strokeWidth="1.5" strokeDasharray="4,3" />
    <line x1="480" y1="65" x2="480" y2="290" stroke="#1d4ed8" strokeWidth="1.5" strokeDasharray="4,3" />
    {/* Message 1 */}
    <line x1="480" y1="100" x2="100" y2="100" stroke="#1d4ed8" strokeWidth="2" markerEnd="url(#arrLeft)" />
    <defs>
      <marker id="arrLeft" markerWidth="8" markerHeight="8" refX="2" refY="3" orient="auto">
        <path d="M8,0 L8,6 L0,3 z" fill="#1d4ed8" />
      </marker>
      <marker id="arrRight" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0,0 L0,6 L8,3 z" fill="#16a34a" />
      </marker>
    </defs>
    <rect x="160" y="85" width="260" height="22" rx="4" fill="#eff6ff" stroke="#93c5fd" strokeWidth="1" />
    <text x="290" y="100" textAnchor="middle" fontSize="10" fill="#1e40af">消息1: ANonce (AP随机数)</text>
    {/* Message 2 */}
    <line x1="100" y1="150" x2="480" y2="150" stroke="#16a34a" strokeWidth="2" markerEnd="url(#arrRight)" />
    <rect x="160" y="135" width="260" height="22" rx="4" fill="#f0fdf4" stroke="#86efac" strokeWidth="1" />
    <text x="290" y="150" textAnchor="middle" fontSize="10" fill="#15803d">消息2: SNonce + MIC (STA随机数+完整性校验)</text>
    {/* PTK derived note */}
    <text x="100" y="175" textAnchor="middle" fontSize="9" fill="#059669" fontStyle="italic">→ 生成 PTK</text>
    <text x="480" y="175" textAnchor="middle" fontSize="9" fill="#059669" fontStyle="italic">← 生成 PTK</text>
    {/* Message 3 */}
    <line x1="480" y1="205" x2="100" y2="205" stroke="#1d4ed8" strokeWidth="2" markerEnd="url(#arrLeft)" />
    <rect x="160" y="190" width="260" height="22" rx="4" fill="#eff6ff" stroke="#93c5fd" strokeWidth="1" />
    <text x="290" y="205" textAnchor="middle" fontSize="10" fill="#1e40af">消息3: GTK + MIC (组密钥+完整性校验)</text>
    {/* Message 4 */}
    <line x1="100" y1="250" x2="480" y2="250" stroke="#16a34a" strokeWidth="2" markerEnd="url(#arrRight)" />
    <rect x="160" y="235" width="260" height="22" rx="4" fill="#f0fdf4" stroke="#86efac" strokeWidth="1" />
    <text x="290" y="250" textAnchor="middle" fontSize="10" fill="#15803d">消息4: ACK (确认安装密钥)</text>
    {/* Result */}
    <rect x="180" y="268" width="220" height="22" rx="6" fill="#d1fae5" stroke="#059669" strokeWidth="1.5" />
    <text x="290" y="282" textAnchor="middle" fontSize="11" fill="#065f46" fontWeight="bold">✓ 安全会话建立，开始加密通信</text>
  </svg>
);

const ChannelPlanSVG = () => (
  <svg viewBox="0 0 580 220" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 220 }}>
    <text x="290" y="20" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#b45309">2.4 GHz 信道规划（非重叠信道）</text>
    {/* Frequency axis */}
    <line x1="30" y1="160" x2="560" y2="160" stroke="#78716c" strokeWidth="2" />
    <text x="30" y="175" fontSize="9" fill="#78716c">2.412</text>
    <text x="100" y="175" fontSize="9" fill="#78716c">2.437</text>
    <text x="200" y="175" fontSize="9" fill="#78716c">2.462</text>
    <text x="280" y="175" fontSize="9" fill="#78716c">GHz</text>
    {/* Channel bands */}
    {/* Channel 1: 2.401-2.423 */}
    <ellipse cx="80" cy="100" rx="70" ry="60" fill="#fde68a" fillOpacity="0.6" stroke="#d97706" strokeWidth="2.5" />
    <text x="80" y="97" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#92400e">CH 1</text>
    <text x="80" y="112" textAnchor="middle" fontSize="10" fill="#b45309">2.412 GHz</text>
    {/* Channel 6: 2.426-2.448 */}
    <ellipse cx="230" cy="100" rx="70" ry="60" fill="#bbf7d0" fillOpacity="0.6" stroke="#16a34a" strokeWidth="2.5" />
    <text x="230" y="97" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#15803d">CH 6</text>
    <text x="230" y="112" textAnchor="middle" fontSize="10" fill="#16a34a">2.437 GHz</text>
    {/* Channel 11: 2.451-2.473 */}
    <ellipse cx="380" cy="100" rx="70" ry="60" fill="#bfdbfe" fillOpacity="0.6" stroke="#1d4ed8" strokeWidth="2.5" />
    <text x="380" y="97" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#1e40af">CH 11</text>
    <text x="380" y="112" textAnchor="middle" fontSize="10" fill="#1d4ed8">2.462 GHz</text>
    {/* Non-overlap label */}
    <text x="290" y="198" textAnchor="middle" fontSize="11" fill="#78716c" fontStyle="italic">三条非重叠信道相距 25 MHz，可同时部署不互相干扰</text>
    {/* 5GHz note */}
    <rect x="460" y="65" width="110" height="55" rx="6" fill="#f0f9ff" stroke="#0369a1" strokeWidth="1.5" />
    <text x="515" y="82" textAnchor="middle" fontSize="11" fill="#0c4a6e" fontWeight="bold">5 GHz 频段</text>
    <text x="515" y="97" textAnchor="middle" fontSize="10" fill="#0369a1">23+ 非重叠</text>
    <text x="515" y="110" textAnchor="middle" fontSize="10" fill="#0369a1">信道可用</text>
  </svg>
);

const StandardsComparisonSVG = () => (
  <svg viewBox="0 0 620 260" className="w-full max-w-2xl mx-auto" style={{ maxHeight: 260 }}>
    <text x="310" y="22" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#1e293b">802.11 标准演进对比</text>
    {/* Header */}
    {['标准','频段','最高速率','调制方式','发布年份'].map((_h, i) => (
      <rect key={i} x={10 + i * 120} y={32} width={118} height={28} fill="#1e293b" rx={i === 0 ? '4 0 0 4' : i === 4 ? '0 4 4 0' : '0'} />
    ))}
    {['标准','频段','最高速率','调制方式','发布年份'].map((h, i) => (
      <text key={i} x={10 + i * 120 + 59} y={51} textAnchor="middle" fontSize="11" fill="white" fontWeight="bold">{h}</text>
    ))}
    {/* Rows */}
    {[
      ['802.11 (原始)', '2.4 GHz', '2 Mbps', 'FHSS / DSSS', '1997'],
      ['802.11b', '2.4 GHz', '11 Mbps', 'HR/DSSS (CCK)', '1999'],
      ['802.11a', '5 GHz', '54 Mbps', 'OFDM', '1999'],
      ['802.11g', '2.4 GHz', '54 Mbps', 'OFDM + DSSS', '2003'],
      ['802.11n', '2.4/5 GHz', '600 Mbps', 'MIMO-OFDM', '2009'],
    ].map((row, ri) => {
      const bg = ri % 2 === 0 ? '#f8fafc' : '#f1f5f9';
      return (
        <g key={ri}>
          {row.map((cell, ci) => (
            <g key={ci}>
              <rect x={10 + ci * 120} y={60 + ri * 38} width={118} height={36} fill={bg} stroke="#cbd5e1" strokeWidth="1" />
              <text x={10 + ci * 120 + 59} y={83 + ri * 38} textAnchor="middle" fontSize="10.5" fill="#334155">{cell}</text>
            </g>
          ))}
        </g>
      );
    })}
    {/* Speed bar chart */}
    {[2, 11, 54, 54, 600].map((speed, i) => {
      const maxW = 80;
      const w = Math.max(2, (speed / 600) * maxW);
      return (
        <rect key={i} x={10 + 4 * 120 + 118 + 5} y={63 + i * 38} width={w} height={30}
          fill={['#818cf8','#34d399','#f59e0b','#60a5fa','#c084fc'][i]} rx="3" opacity="0.85" />
      );
    })}
  </svg>
);

const chapters_content: Record<string, React.ReactNode> = {
  preface: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/80211-wireless-networks/0596100523/pr03.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/80211-wireless-networks/0596100523/pr03.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">《802.11 无线网络权威指南》前言</h2>
      <p className="text-gray-700 leading-relaxed">
        <strong>作者：Matthew Gast（O'Reilly，2005年第二版）</strong>
      </p>
      <blockquote className="border-l-4 border-gray-300 pl-4 italic text-gray-600">
        "人在移动，网络不动。" —— 这两句话最能解释无线局域网硬件爆发式增长的原因。
      </blockquote>
      <p className="text-gray-700 leading-relaxed">
        在短短几年内，无线局域网已从高价的极客玩具演变为主流技术。通过将用户连接与物理位置解耦，无线网络赋予用户真正的移动自由。然而，这种自由需要大量协议工程的支撑——网络必须高度感知用户位置，才能提供与位置无关的服务。
      </p>
      <h3 className="text-xl font-semibold text-gray-900 mt-6">无线局域网的可能性</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {[
          { title: '移动性', desc: '用户可以在移动中访问集中存储的数据，显著提升生产力。' },
          { title: '灵活性', desc: '无需重新布线即可重新配置网络，适应不断变化的工作环境。' },
          { title: '快速部署', desc: '无线网络的安装速度远快于有线基础设施，尤其适用于临时场所。' },
          { title: '降低成本', desc: '对于难以布线的历史建筑或临时办公场所，无线是更经济的选择。' },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <h4 className="font-semibold text-indigo-700 mb-1">{item.title}</h4>
            <p className="text-gray-600 text-sm">{item.desc}</p>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mt-6">本书面向读者</h3>
      <p className="text-gray-700 leading-relaxed">
        本书面向网络管理员、架构师和安全专业人员。第二版于2005年发布，较第一版（2002年）新增了802.11g、802.11n（MIMO-OFDM前瞻）、802.11i安全规范等重要内容，并对管理章节进行了大幅修订以涵盖802.11h频谱管理。
      </p>
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-amber-800 text-sm font-medium">📚 版本信息</p>
        <ul className="mt-2 text-amber-700 text-sm space-y-1">
          <li>• 第一版：2002年4月，ISBN: 0-596-00183-5，464页</li>
          <li>• 第二版：2005年4月，ISBN: 0-596-10052-3，656页（本书所依据版本）</li>
          <li>• 出版社：O'Reilly Media</li>
        </ul>
      </div>
    </div>
  ),

  ch1: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch01.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch01.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第1章：无线网络简介</h2>
      <h3 className="text-xl font-semibold text-gray-800">1.1 为什么选择无线？</h3>
      <p className="text-gray-700 leading-relaxed">
        无线网络的核心优势是<strong>移动性</strong>。有线网络将用户束缚在以太网接口旁，而无线网络打破了这一限制。除移动性外，无线网络还带来灵活性、更快的部署速度，以及对难以布线区域的覆盖能力。
      </p>
      <p className="text-gray-700 leading-relaxed">
        然而，无线网络并非没有代价：它引入了全新的安全挑战、RF干扰问题，以及比有线网络更复杂的协议栈。理解这些权衡，是本书的核心目标。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">1.2 无线网络的不同之处</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-200 px-4 py-2 text-left">特性</th>
              <th className="border border-gray-200 px-4 py-2 text-left">有线网络</th>
              <th className="border border-gray-200 px-4 py-2 text-left">无线网络</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['信道质量', '稳定，低误码率', '随时间和位置变化，高误码率'],
              ['碰撞检测', 'CSMA/CD，可检测', 'CSMA/CA，无法检测（用避免代替）'],
              ['广播域', '物理隔离', 'RF信号可穿越墙壁，难以物理隔离'],
              ['移动性', '固定端口', '支持漫游，需要重关联机制'],
              ['安全边界', '物理连接', 'RF信号外泄，需加密保护'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => (
                  <td key={j} className="border border-gray-200 px-4 py-2 text-gray-700">{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">1.3 网络名称体系</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 标准由 IEEE 802.11 工作组制定，是所有 Wi-Fi 产品的技术基础。"Wi-Fi"是 Wi-Fi 联盟（Wi-Fi Alliance）的互操作性认证商标，最初特指 802.11b，后扩展到所有认证的 802.11 变体。
      </p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
        <p className="text-blue-800 text-sm">
          <strong>关键区别：</strong> IEEE 802.11 是技术标准规范，而"Wi-Fi"是互操作性认证品牌。所有 Wi-Fi 设备都基于 802.11，但不是所有 802.11 设备都有 Wi-Fi 认证。
        </p>
      </div>
      <StandardsComparisonSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图1-1：802.11 标准族演进历程</p>
    </div>
  ),

  ch2: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch02.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch02.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第2章：802.11 网络概览</h2>
      <h3 className="text-xl font-semibold text-gray-800">2.1 IEEE 802 网络技术家族树</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 是 IEEE 802 LAN 标准家族的成员。该家族专注于局域网技术，定义了 MAC（媒体访问控制）层和 PHY（物理）层。家族成员包括：
      </p>
      <ul className="list-disc pl-6 text-gray-700 space-y-1">
        <li><strong>802.3</strong>：以太网（最主流的有线 LAN）</li>
        <li><strong>802.5</strong>：令牌环网</li>
        <li><strong>802.11</strong>：无线局域网（Wi-Fi）</li>
        <li><strong>802.1X</strong>：基于端口的网络访问控制（用于认证）</li>
      </ul>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">2.2 802.11 命名与设计</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 网络由四个核心组件构成：
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {[
          { name: '分布式系统 (DS)', desc: '接入点之间互联的骨干网络（通常是以太网），负责在 BSS 间转发帧。' },
          { name: '接入点 (AP)', desc: '连接无线客户端与有线分布式系统的桥接设备，是基础设施网络的核心。' },
          { name: '无线介质 (WM)', desc: '802.11 使用射频（RF）信号作为无线介质，在 2.4 GHz 或 5 GHz 频段运行。' },
          { name: '站点 (STA)', desc: '任何具备 802.11 接口的设备（笔记本、手机、IoT 设备等）。' },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-indigo-100 rounded-lg p-4 shadow-sm">
            <h4 className="font-semibold text-indigo-700 mb-1">{item.name}</h4>
            <p className="text-gray-600 text-sm">{item.desc}</p>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">网络拓扑图</h3>
      <NetworkArchSVG />
      <p className="text-center text-sm text-gray-500">图2-1：802.11 基础设施网络架构（ESS 包含多个 BSS）</p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">2.3 802.11 网络操作</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 定义了九种基本服务，分为两类：
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <p className="font-semibold text-gray-800 mb-2">站点服务（SS）</p>
          <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
            <li>认证（Authentication）</li>
            <li>去认证（Deauthentication）</li>
            <li>隐私（Privacy / 加密）</li>
            <li>MSDU 传送</li>
          </ul>
        </div>
        <div>
          <p className="font-semibold text-gray-800 mb-2">分布式系统服务（DSS）</p>
          <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
            <li>关联（Association）</li>
            <li>去关联（Disassociation）</li>
            <li>重关联（Reassociation）</li>
            <li>分发（Distribution）</li>
            <li>集成（Integration）</li>
          </ul>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">2.4 移动性支持</h3>
      <p className="text-gray-700 leading-relaxed">802.11 定义了三种迁移类型：</p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">类型</th>
            <th className="border border-gray-200 px-3 py-2">描述</th>
            <th className="border border-gray-200 px-3 py-2">连接影响</th>
          </tr></thead>
          <tbody>
            {[
              ['无迁移', '站点在同一 AP 覆盖范围内移动', '无影响'],
              ['BSS 迁移', '站点从一个 BSS 移动到同一 ESS 的另一个 BSS', '需重关联，上层连接可维持'],
              ['ESS 迁移', '站点跨 ESS 移动', '上层连接中断，802.11 层面不支持'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  ),

  ch3: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch03.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch03.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第3章：802.11 MAC 基础</h2>
      <h3 className="text-xl font-semibold text-gray-800">3.1 MAC 层的挑战</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 MAC 层面临的核心挑战与有线以太网截然不同：
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h4 className="font-semibold text-red-700 mb-2">RF 链路质量问题</h4>
          <p className="text-sm text-gray-700">无线信道的误码率远高于有线，受多径衰落、干扰、距离等影响。802.11 MAC 必须内建重传机制来应对丢包。</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <h4 className="font-semibold text-orange-700 mb-2">隐藏节点问题</h4>
          <p className="text-sm text-gray-700">站点 A 和站点 C 都能与 AP 通信，但彼此无法感知对方的信号。两者同时发送时，AP 处发生碰撞，而两个站点均无法检测到。</p>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">3.2 MAC 访问模式与时序</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 定义了两种访问模式：<strong>DCF（分布式协调功能）</strong>和 <strong>PCF（点协调功能）</strong>。DCF 是强制实现的基础访问方式，基于 CSMA/CA；PCF 为可选的无竞争访问方式，实际上极少部署。
      </p>
      <p className="text-gray-700 leading-relaxed">
        <strong>帧间间隔（IFS）</strong>是 802.11 时序控制的核心，不同类型的间隔赋予不同流量不同优先级：
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">间隔类型</th>
            <th className="border border-gray-200 px-3 py-2">全称</th>
            <th className="border border-gray-200 px-3 py-2">用途与优先级</th>
          </tr></thead>
          <tbody>
            {[
              ['SIFS', '短帧间间隔', '最高优先级，用于 ACK、CTS 等即时响应（20μs，802.11b）'],
              ['PIFS', '点协调功能帧间间隔', 'PCF 专用，高于 DCF 优先级'],
              ['DIFS', '分布式帧间间隔', '标准数据帧发送前的等待时间（50μs，802.11b）'],
              ['EIFS', '扩展帧间间隔', '接收到错误帧后的等待时间，最低优先级'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">3.3 基于竞争的访问：DCF（CSMA/CA）</h3>
      <DCFFlowSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图3-1：DCF 访问流程与退避机制</p>
      <p className="text-gray-700 leading-relaxed mt-4">
        DCF 使用 <strong>CSMA/CA</strong>（载波侦听多路访问/碰撞避免）。与以太网的 CSMA/CD（碰撞检测）不同，无线环境无法在发送的同时可靠地侦听信道，因此采用"避免"而非"检测"策略：
      </p>
      <ol className="list-decimal pl-6 text-gray-700 space-y-2 text-sm">
        <li>站点在发送前侦听信道，确认空闲 DIFS 时间后方可发送。</li>
        <li>若信道忙，等待至空闲后再选择随机退避时间（Random Backoff）。</li>
        <li>退避计数器只在信道空闲时递减，信道忙时暂停。</li>
        <li>计数器归零后发送帧，接收方在 SIFS 后回送 ACK。</li>
        <li>若未收到 ACK，进入重传，退避窗口翻倍（指数退避）。</li>
      </ol>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-800 text-sm"><strong>RTS/CTS 机制（解决隐藏节点）：</strong> 发送方先发 RTS（请求发送），接收方回复 CTS（允许发送）。所有听到 RTS 或 CTS 的站点更新自己的 NAV（网络分配向量），在该时段内保持静默，从而避免碰撞。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">3.4 分片与重组</h3>
      <p className="text-gray-700 leading-relaxed">
        在噪声较大的环境中，较大的帧更容易出错。802.11 支持将 MSDU 分片为多个较小的 MPDU 单独发送，降低每片出错的概率，提升整体吞吐量。接收方负责重组。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">3.5–3.8 帧格式、高层协议封装与桥接</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 帧通过 <strong>802.2 LLC</strong> 封装高层协议（如 IP）。帧体最大为 2304 字节。MAC 层还负责在无线介质与有线以太网之间进行帧转换（桥接），AP 充当透明桥接器。
      </p>
    </div>
  ),

  ch4: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch04.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch04.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第4章：802.11 帧详解</h2>
      <FrameFormatSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图4-1：802.11 通用帧格式</p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">4.1 数据帧</h3>
      <p className="text-gray-700 leading-relaxed">
        数据帧承载上层协议数据（如 IP 包）。根据 <strong>To DS</strong> 和 <strong>From DS</strong> 两个标志位的组合，地址字段含义不同：
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">To DS</th>
            <th className="border border-gray-200 px-3 py-2">From DS</th>
            <th className="border border-gray-200 px-3 py-2">地址1</th>
            <th className="border border-gray-200 px-3 py-2">地址2</th>
            <th className="border border-gray-200 px-3 py-2">地址3</th>
            <th className="border border-gray-200 px-3 py-2">地址4</th>
          </tr></thead>
          <tbody>
            {[
              ['0','0','目的地','源地址','BSSID','—（IBSS）'],
              ['1','0','BSSID','源地址','目的地','—（STA→AP）'],
              ['0','1','目的地','BSSID','源地址','—（AP→STA）'],
              ['1','1','接收AP','发送AP','目的地','源（WDS）'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">4.2 控制帧</h3>
      <p className="text-gray-700 leading-relaxed">控制帧辅助数据帧的传送，主要类型：</p>
      <ul className="list-disc pl-6 text-gray-700 space-y-1 text-sm">
        <li><strong>RTS（请求发送）</strong>：保留信道，解决隐藏节点问题</li>
        <li><strong>CTS（允许发送）</strong>：响应 RTS，允许发送方传输</li>
        <li><strong>ACK（确认）</strong>：确认单播帧成功接收</li>
        <li><strong>PS-Poll（省电轮询）</strong>：处于省电模式的站点向 AP 请求缓冲数据</li>
        <li><strong>CF-End（无竞争结束）</strong>：PCF 模式下结束无竞争周期</li>
      </ul>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">4.3 管理帧</h3>
      <p className="text-gray-700 leading-relaxed">管理帧负责维护网络的运行状态，核心类型：</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {[
          { name: 'Beacon（信标）', desc: '由 AP 定期广播，公告网络存在、参数及时间同步信息（默认约100ms/次）。' },
          { name: 'Probe Request/Response', desc: '主动扫描时，站点发送 Probe Request；AP 以 Probe Response 回应。' },
          { name: 'Authentication', desc: '执行第一阶段认证（开放系统或共享密钥）。' },
          { name: 'Association Request/Response', desc: '站点完成认证后请求关联，AP 分配 Association ID（AID）。' },
          { name: 'Reassociation', desc: '漫游时，站点向新 AP 请求重关联，携带原 AP 信息。' },
          { name: 'Disassociation/Deauthentication', desc: '断开关联或认证关系，释放资源。' },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-gray-200 rounded-lg p-3 shadow-sm">
            <h4 className="font-semibold text-gray-800 text-sm mb-1">{item.name}</h4>
            <p className="text-gray-600 text-xs">{item.desc}</p>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">4.4 帧传输与关联/认证状态机</h3>
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <p className="text-gray-700 text-sm leading-relaxed">
          站点与 AP 之间存在三个状态：<br/>
          <strong>状态1</strong>：未认证、未关联（初始状态，只能收发特定管理帧）<br/>
          <strong>状态2</strong>：已认证、未关联（可开始关联流程）<br/>
          <strong>状态3</strong>：已认证、已关联（可正常传输数据帧）<br/>
          状态机确保在完成认证和关联之前，站点无法发送数据帧。
        </p>
      </div>
    </div>
  ),

  ch5: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch05.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch05.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第5章：有线等效保密（WEP）</h2>
      <div className="bg-red-50 border border-red-300 rounded-lg p-4">
        <p className="text-red-800 font-semibold">⚠️ 重要警告</p>
        <p className="text-red-700 text-sm mt-1">WEP 已被证明存在根本性的密码学缺陷，不应在任何需要安全保障的现代网络中使用。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800">5.1 WEP 的密码学背景</h3>
      <p className="text-gray-700 leading-relaxed">
        WEP（Wired Equivalent Privacy，有线等效保密）设计目标是为无线链路提供与有线网络"等效"的安全性。它基于 <strong>RC4 流密码</strong>，使用 40 位或 104 位静态密钥（加上 24 位初始向量 IV，共 64 位或 128 位）。
      </p>
      <WEPDiagramSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图5-1：WEP 加密流程（IV + 密钥 → RC4 密钥流 ⊕ 明文 = 密文）</p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">5.2 WEP 加密操作</h3>
      <ol className="list-decimal pl-6 text-gray-700 space-y-2 text-sm">
        <li>计算明文的 CRC-32 校验值（ICV），附加在明文末尾。</li>
        <li>生成随机 24 位初始向量（IV），与 WEP 密钥拼接。</li>
        <li>将 IV+密钥 输入 RC4 算法，生成密钥流。</li>
        <li>明文+ICV 与密钥流进行 XOR 运算，生成密文。</li>
        <li>IV 以<strong>明文</strong>形式附加在帧头，与密文一同发送。</li>
      </ol>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">5.3 WEP 的问题</h3>
      <div className="space-y-3">
        {[
          { title: 'IV 空间过小（24位）', desc: '24 位 IV 最多 1600 万个值，在繁忙网络中数小时内即可耗尽，IV 必然重用。使用相同 IV+密钥 产生的两个密文异或后可消除密钥流，直接暴露明文关系。' },
          { title: 'RC4 密钥调度弱点', desc: 'Fluhrer、Mantin 和 Shamir（2001年，"FMS攻击"）发现，RC4 密钥调度算法对某些 IV 存在弱点，可通过大量弱 IV 统计分析还原密钥。AirSnort 等工具可在数小时内破解 WEP。' },
          { title: 'ICV 完整性校验不可靠', desc: 'CRC-32 是线性函数，攻击者可在不知道密钥的情况下修改密文并调整 ICV，使接收方接受被篡改的帧（比特翻转攻击）。' },
          { title: '无密钥管理机制', desc: 'WEP 没有定义密钥分发和更新机制。企业环境中，同一静态密钥可能被数百台设备共用，更换密钥极为困难。' },
        ].map((item, i) => (
          <div key={i} className="bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg">
            <h4 className="font-semibold text-red-700 mb-1">{item.title}</h4>
            <p className="text-sm text-gray-700">{item.desc}</p>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">5.4 动态 WEP</h3>
      <p className="text-gray-700 leading-relaxed">
        作为临时缓解措施，动态 WEP 结合 802.1X/EAP 为每个会话（甚至每个帧）生成唯一的 WEP 密钥，解决了静态密钥管理问题。但 IV 空间和 RC4 弱点依然存在，最终被 TKIP 和 CCMP 取代。
      </p>
    </div>
  ),

  ch6: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch06.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch06.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第6章：802.1X 用户认证</h2>
      <h3 className="text-xl font-semibold text-gray-800">6.1 可扩展认证协议（EAP）</h3>
      <p className="text-gray-700 leading-relaxed">
        EAP（Extensible Authentication Protocol，RFC 3748）是一个认证框架，而非特定的认证机制。它定义了一种灵活的消息格式，允许在其上运行各种具体的认证方法，而无需修改底层协议。
      </p>
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm">
        <p className="font-semibold text-gray-800 mb-2">EAP 消息格式：</p>
        <div className="flex gap-2 flex-wrap">
          {['Code (1字节)', 'Identifier (1字节)', 'Length (2字节)', 'Data (变长)'].map((f, i) => (
            <span key={i} className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded text-xs font-mono">{f}</span>
          ))}
        </div>
        <p className="text-gray-600 mt-2">Code 值：1=Request，2=Response，3=Success，4=Failure</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">6.2 EAP 认证方法</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">方法</th>
            <th className="border border-gray-200 px-3 py-2">安全性</th>
            <th className="border border-gray-200 px-3 py-2">特点</th>
          </tr></thead>
          <tbody>
            {[
              ['EAP-TLS (代码13)', '极高', '双向证书认证（客户端+服务器），最强安全性，需PKI基础设施'],
              ['EAP-TTLS (代码21)', '高', '服务器证书+内层认证（如MSCHAPv2），无需客户端证书'],
              ['PEAP (代码25)', '高', 'TLS隧道内嵌MSCHAPv2或GTC，微软/思科主推'],
              ['LEAP', '低（已弱化）', 'Cisco专有，基于CHAP的挑战-响应，存在字典攻击漏洞'],
              ['EAP-SIM (代码18)', '中', '使用SIM卡进行认证，面向运营商Wi-Fi'],
              ['MD5 Challenge', '低（不推荐）', '仅认证客户端，无服务器认证，无动态密钥'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">6.3 802.1X：基于端口的网络访问控制</h3>
      <p className="text-gray-700 leading-relaxed">
        802.1X 定义了三个角色：
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { name: '请求方（Supplicant）', desc: '客户端设备，运行 EAP 认证软件（如 Windows 内置的 WZC，或 xsupplicant）。' },
          { name: '认证方（Authenticator）', desc: '接入点（AP），充当请求方和认证服务器之间的透明中继。' },
          { name: '认证服务器（AS）', desc: '通常是 RADIUS 服务器（如 FreeRADIUS），执行实际的认证决策。' },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-indigo-200 rounded-lg p-4 shadow-sm">
            <h4 className="font-semibold text-indigo-700 text-sm mb-1">{item.name}</h4>
            <p className="text-gray-600 text-xs">{item.desc}</p>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">6.4 802.1X 在无线局域网上的应用</h3>
      <p className="text-gray-700 leading-relaxed">
        EAP 消息通过 <strong>EAPOL（EAP over LAN）</strong>协议在无线链路上传输，到达 AP 后，AP 将其封装为 <strong>RADIUS</strong> 报文转发给认证服务器。认证成功后，RADIUS 服务器将会话密钥安全地分发给 AP，用于后续的动态密钥加密。
      </p>
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <p className="text-green-800 text-sm">
          <strong>802.1X + EAP 认证成功后的关键输出：</strong> 生成的 MSK（主会话密钥）由请求方和认证服务器共同持有，AP 通过 RADIUS 属性获取，用于推导后续 802.11i 的加密密钥。
        </p>
      </div>
    </div>
  ),

  ch7: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch07.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch07.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第7章：802.11i：健壮安全网络、TKIP 与 CCMP</h2>
      <p className="text-gray-700 leading-relaxed">
        802.11i（2004年批准）是修复 WEP 弱点的完整安全框架，引入了<strong>健壮安全网络（RSN）</strong>概念，定义了 TKIP 和 CCMP 两种加密协议，以及基于 802.1X 的密钥管理机制。
      </p>
      <h3 className="text-xl font-semibold text-gray-800">7.1 TKIP（临时密钥完整性协议）</h3>
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-amber-800 text-sm font-medium">TKIP 是对 WEP 的改进补丁，设计目标是在不更换旧硬件的情况下增强安全性（通过固件升级实现）。</p>
      </div>
      <p className="text-gray-700 leading-relaxed mt-2">TKIP 相对 WEP 的改进：</p>
      <ul className="list-disc pl-6 text-gray-700 space-y-1 text-sm">
        <li><strong>每包密钥混合</strong>：将 48 位 TSC（TKIP 序列计数器）与基密钥混合，每个帧使用唯一密钥，消除弱 IV 问题。</li>
        <li><strong>扩展 IV 空间</strong>：使用 48 位序列号替代 24 位 IV，理论上穷尽需数百年。</li>
        <li><strong>Michael MIC</strong>：新增 8 字节消息完整性校验码，防止比特翻转攻击。若检测到 MIC 失败，触发反制措施（60 秒内暂停通信）。</li>
        <li><strong>序列号防重放</strong>：接收方检查 TSC，拒绝乱序或重放的帧。</li>
      </ul>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">7.2 CCMP（带 CBC-MAC 的计数器模式）</h3>
      <p className="text-gray-700 leading-relaxed">
        CCMP 是 802.11i 的首选（强制）加密协议，基于 <strong>AES（高级加密标准）</strong>，同时提供机密性和完整性保护：
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white border border-green-200 rounded-lg p-4 shadow-sm">
          <h4 className="font-semibold text-green-700 mb-2">CTR 模式（机密性）</h4>
          <p className="text-sm text-gray-700">AES 计数器模式加密，计数器从 PN（包序号）递增，每个 128 位块独立加密，支持并行处理。</p>
        </div>
        <div className="bg-white border border-blue-200 rounded-lg p-4 shadow-sm">
          <h4 className="font-semibold text-blue-700 mb-2">CBC-MAC（完整性）</h4>
          <p className="text-sm text-gray-700">CBC-MAC 模式生成 MIC（8字节），覆盖帧头和帧体，检测任何篡改。远强于 WEP 的 CRC-32。</p>
        </div>
      </div>
      <div className="bg-green-50 border border-green-200 rounded-lg p-4 mt-4">
        <p className="text-green-800 text-sm"><strong>为什么 CCMP 优于 TKIP：</strong> CCMP 基于 AES（而非存在弱点的 RC4），在算法层面安全；TKIP 仅是 WEP 的补丁，仍使用 RC4，存在理论上的 Michael MIC 攻击风险。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">7.3 健壮安全网络（RSN）操作</h3>
      <RSNHandshakeSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图7-1：802.11i 四次握手密钥推导与分发流程</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
        <div>
          <p className="font-semibold text-gray-800 mb-2 text-sm">成对密钥层次（PTK）</p>
          <ul className="text-xs text-gray-700 space-y-1 list-disc pl-4">
            <li>KCK（密钥确认密钥）：保护四次握手</li>
            <li>KEK（密钥加密密钥）：加密分发 GTK</li>
            <li>TK（临时密钥）：实际数据加密密钥</li>
          </ul>
        </div>
        <div>
          <p className="font-semibold text-gray-800 mb-2 text-sm">组密钥（GTK）</p>
          <ul className="text-xs text-gray-700 space-y-1 list-disc pl-4">
            <li>用于加密广播/组播帧</li>
            <li>AP 生成，通过组密钥握手分发给所有关联站点</li>
            <li>站点离开时应更新 GTK</li>
          </ul>
        </div>
      </div>
    </div>
  ),

  ch8: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch08.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch08.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第8章：管理操作</h2>
      <h3 className="text-xl font-semibold text-gray-800">8.1 管理架构</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 管理操作由一系列协议步骤构成，允许站点发现、加入和维护与网络的关联关系。所有管理操作均通过管理帧交换完成，不涉及数据面流量。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">8.2 扫描</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white border border-blue-200 rounded-lg p-4">
          <h4 className="font-semibold text-blue-700 mb-2">被动扫描</h4>
          <p className="text-sm text-gray-700">站点在各信道侦听 Beacon 帧。Beacon 由 AP 每约 100ms 广播一次，包含 SSID、BSSID、支持速率、安全能力等信息。被动扫描功耗低，但发现网络较慢。</p>
        </div>
        <div className="bg-white border border-green-200 rounded-lg p-4">
          <h4 className="font-semibold text-green-700 mb-2">主动扫描</h4>
          <p className="text-sm text-gray-700">站点主动发送 Probe Request（可指定 SSID 或广播），AP 以 Probe Response 回应。主动扫描发现速度更快，但功耗较高，隐藏 SSID 的 AP 可能不响应广播 Probe。</p>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">8.3 认证</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 定义了两种链路层认证方式（注意：这与上层 802.1X 认证不同）：
      </p>
      <ul className="list-disc pl-6 text-gray-700 space-y-1 text-sm">
        <li><strong>开放系统认证（Open System）</strong>：默认方式，无实质安全性验证，任何站点均可通过。</li>
        <li><strong>共享密钥认证（Shared Key）</strong>：使用 WEP 密钥进行挑战-响应认证，但实际上比开放系统更不安全（暴露明文-密文对，有助于密钥分析）。</li>
      </ul>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">8.4 关联与预认证</h3>
      <p className="text-gray-700 leading-relaxed">
        认证完成后，站点发送 Association Request，AP 分配 AID（关联标识符）并返回 Association Response。<strong>预认证（Preauthentication）</strong>允许站点在漫游前提前向目标 AP 完成认证，减少切换延迟。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">8.5 省电管理</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 省电模式（PSM）允许站点定期进入低功耗休眠状态。AP 在 Beacon 的 TIM（流量指示图）中标记哪些处于休眠的站点有待发帧缓冲。站点醒来后，发送 PS-Poll 向 AP 取回缓冲帧。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">8.6 定时器同步与 8.7 频谱管理</h3>
      <p className="text-gray-700 leading-relaxed">
        <strong>TSF（时间同步功能）</strong>使网络内所有站点维持统一时钟，用于 Beacon 调度、PCF 操作和省电同步。<strong>频谱管理（802.11h）</strong>是 5GHz 802.11a 在欧洲部署的强制要求，包括动态频率选择（DFS）和发射功率控制（TPC），以避免与雷达系统干扰。
      </p>
    </div>
  ),

  ch9: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch09.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch09.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第9章：无竞争服务与 PCF</h2>
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-amber-800 text-sm font-medium">⚠️ 实际部署注意</p>
        <p className="text-amber-700 text-sm mt-1">PCF 在实际中几乎未被部署，正如书中所言："PCF has not been widely implemented."（PCF 尚未被广泛实现。）在规划网络时无需考虑 PCF。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">9.1 使用 PCF 的无竞争访问</h3>
      <p className="text-gray-700 leading-relaxed">
        PCF（点协调功能）是 802.11 可选的无竞争访问机制，由 AP（充当点协调器 PC）集中轮询各站点，避免了 DCF 的随机竞争，理论上可为时延敏感流量（如语音）提供确定性服务。
      </p>
      <p className="text-gray-700 leading-relaxed">
        PCF 将时间划分为交替的 <strong>CFP（无竞争周期）</strong>和 <strong>CP（竞争周期）</strong>。CFP 始于 Beacon 帧（包含 CFP 参数），AP 通过 CF-Poll 帧逐一允许站点发送，CF-End 结束 CFP 并切换回 DCF。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">9.2 PCF 帧格式详解</h3>
      <p className="text-gray-700 leading-relaxed">
        PCF 使用特殊的数据+CF-Poll 组合帧，AP 可在向站点发送数据的同时，给予其发送权限（轮询），提高信道利用效率。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">9.3 PCF 与省电管理</h3>
      <p className="text-gray-700 leading-relaxed">
        在 PCF 模式下，省电管理较 DCF 更复杂。站点必须在 CFP 期间保持活跃以响应轮询，这限制了 PCF 环境中的省电效果。802.11e（QoS 扩展）的 HCCA 模式是 PCF 的真正继任者，但同样部署稀少。
      </p>
    </div>
  ),

  ch10: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch10.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch10.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第10章：物理层概览</h2>
      <h3 className="text-xl font-semibold text-gray-800">10.1 物理层架构</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11 物理层分为两个子层：
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white border border-purple-200 rounded-lg p-4">
          <h4 className="font-semibold text-purple-700 mb-2">PLCP 子层</h4>
          <p className="text-sm text-gray-700">物理层汇聚过程（Physical Layer Convergence Procedure）：将 MAC 层帧封装成物理层帧，添加前导码（preamble）和帧头（header），帮助接收方同步。</p>
        </div>
        <div className="bg-white border border-orange-200 rounded-lg p-4">
          <h4 className="font-semibold text-orange-700 mb-2">PMD 子层</h4>
          <p className="text-sm text-gray-700">物理介质相关（Physical Medium Dependent）：负责实际的无线信号调制、发送和接收，直接与射频硬件交互。</p>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">10.2 无线链路特性</h3>
      <p className="text-gray-700 leading-relaxed">射频传播受多种因素影响：</p>
      <ul className="list-disc pl-6 text-gray-700 space-y-1 text-sm">
        <li><strong>路径损耗</strong>：信号强度随距离以平方反比规律衰减，障碍物（墙壁、家具）进一步加剧损耗。</li>
        <li><strong>多径衰落</strong>：信号通过不同路径到达接收方（直射、反射、绕射），各路径信号相位不同，可能相互抵消（衰落）或增强。</li>
        <li><strong>干扰</strong>：2.4 GHz ISM 频段与微波炉、蓝牙、婴儿监视器共用，存在显著干扰风险。</li>
        <li><strong>噪声（热噪声）</strong>：由热运动产生，限制了接收机的灵敏度下限。</li>
      </ul>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">10.3 RF 传播与工程</h3>
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <p className="font-semibold text-gray-800 mb-2 text-sm">关键 RF 工程概念：</p>
        <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
          <li><strong>EIRP（等效全向辐射功率）</strong>：发射功率 + 天线增益，受各国法规限制</li>
          <li><strong>链路预算</strong>：发射功率 - 路径损耗 - 各种损耗 + 天线增益 = 接收信号强度</li>
          <li><strong>SNR（信噪比）</strong>：决定可用的调制速率，SNR 越高，可用速率越高</li>
          <li><strong>天线增益</strong>：方向性天线将能量集中在特定方向，提高覆盖距离</li>
        </ul>
      </div>
      <ChannelPlanSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图10-1：2.4 GHz 非重叠信道规划（1、6、11）</p>
    </div>
  ),

  ch11: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch11.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch11.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第11章：跳频（FH）物理层</h2>
      <p className="text-gray-700 leading-relaxed">
        跳频扩频（FHSS，Frequency Hopping Spread Spectrum）是 802.11 的两种原始物理层之一。信号在多个频点间快速跳变（在 2.4 GHz 频段内跳频），使窄带干扰只能影响部分跳频点，提升了抗干扰能力。
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">11.1 跳频传输</h3>
          <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
            <li>2.4 GHz 频段划分为 79 个 1 MHz 信道</li>
            <li>跳频速率：最低 2.5 跳/秒</li>
            <li>跳频序列由伪随机算法决定，收发双方预先同步序列</li>
            <li>数据速率：1 Mbps 或 2 Mbps（GFSK 调制）</li>
          </ul>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">11.2 GFSK 调制</h3>
          <p className="text-sm text-gray-700">高斯频移键控（Gaussian Frequency Shift Keying）：通过改变载波频率来表示 0 和 1，高斯滤波器平滑频率转换，减少带外干扰。1 Mbps 使用 2-GFSK，2 Mbps 使用 4-GFSK。</p>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">11.3–11.5 FH PHY 帧结构与特性</h3>
      <p className="text-gray-700 leading-relaxed">
        FH PLCP 帧头包含前导码（64位）、同步字（16位）、PLW（帧长）、PSF（帧格式信号）和 HEC（头部错误控制）。由于最高速率仅 2 Mbps，FH PHY 已在商业产品中被完全淘汰，现代 802.11 产品均使用 DS 或 OFDM 物理层。
      </p>
    </div>
  ),

  ch12: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch12.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch12.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第12章：直接序列物理层（DSSS 与 HR/DSSS / 802.11b）</h2>
      <h3 className="text-xl font-semibold text-gray-800">12.1 直接序列传输</h3>
      <p className="text-gray-700 leading-relaxed">
        直接序列扩频（DSSS，Direct Sequence Spread Spectrum）通过将每一位数据与更高速率的伪随机码片序列（PN码）进行 XOR，将信号扩展到更宽的频带。这种扩频增加了抗干扰能力，并允许多个 DSSS 网络在不同信道上共存。
      </p>
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm">
        <p className="font-semibold mb-2">DSSS 关键参数（802.11 原始 DS PHY）：</p>
        <ul className="text-gray-700 space-y-1 list-disc pl-4">
          <li>码片速率：11 Mcps（每秒百万码片）</li>
          <li>扩频码：Barker 码（11位，良好的自相关特性）</li>
          <li>调制：DBPSK（1 Mbps）/ DQPSK（2 Mbps）</li>
          <li>信道带宽：约 22 MHz</li>
        </ul>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">12.3–12.5 802.11b：HR/DSSS 高速直接序列</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11b 是第一个获得广泛商业成功的 Wi-Fi 标准，通过引入 CCK（互补码键控）替代 Barker 码，将速率从 2 Mbps 提升到 5.5 Mbps 和 11 Mbps，同时保持 11 Mcps 码片速率和向后兼容性。
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">速率</th>
            <th className="border border-gray-200 px-3 py-2">调制</th>
            <th className="border border-gray-200 px-3 py-2">扩频码</th>
            <th className="border border-gray-200 px-3 py-2">每码片位数</th>
          </tr></thead>
          <tbody>
            {[
              ['1 Mbps', 'DBPSK', 'Barker 码 (11位)', '1'],
              ['2 Mbps', 'DQPSK', 'Barker 码 (11位)', '2'],
              ['5.5 Mbps', 'DQPSK', 'CCK (4位码字)', '4'],
              ['11 Mbps', 'DQPSK', 'CCK (8位码字)', '8'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  ),

  ch13: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch13.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch13.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第13章：802.11a/j：5 GHz OFDM 物理层</h2>
      <h3 className="text-xl font-semibold text-gray-800">13.1 正交频分复用（OFDM）</h3>
      <p className="text-gray-700 leading-relaxed">
        OFDM（Orthogonal Frequency Division Multiplexing）将单一高速信道分割为多个并行的低速子信道（子载波），各子载波相互正交（互不干扰），在其他载波的峰值处幅度为零。这一特性使各子载波可以紧密排列，极大提高频谱利用率。
      </p>
      <OFDMDiagramSVG />
      <p className="text-center text-sm text-gray-500 mt-2">图13-1：OFDM 子载波正交性示意</p>
      <p className="text-gray-700 leading-relaxed mt-4">
        OFDM 的核心优势是对抗多径衰落：每个子载波速率极低（约250 kbps），符号持续时间远长于多径时延扩展，配合<strong>循环前缀（Guard Interval）</strong>，几乎完全消除了码间干扰（ISI）。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">13.2 802.11a 的 OFDM 实现</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm">
          <p className="font-semibold mb-2">802.11a OFDM 参数：</p>
          <ul className="text-gray-700 space-y-1 list-disc pl-4">
            <li>子载波数：52（48 数据 + 4 导频）</li>
            <li>子载波间隔：312.5 kHz</li>
            <li>FFT 大小：64 点</li>
            <li>循环前缀：800 ns（或 400 ns 短 GI）</li>
            <li>信道带宽：20 MHz</li>
            <li>频段：5 GHz（UNII-1/2/3）</li>
          </ul>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm">
          <p className="font-semibold mb-2">调制与编码率对应速率：</p>
          <ul className="text-gray-700 space-y-1 list-disc pl-4">
            <li>BPSK，1/2 码率 → 6 Mbps</li>
            <li>BPSK，3/4 码率 → 9 Mbps</li>
            <li>QPSK，1/2 码率 → 12 Mbps</li>
            <li>QPSK，3/4 码率 → 18 Mbps</li>
            <li>16-QAM，1/2 → 24 Mbps</li>
            <li>16-QAM，3/4 → 36 Mbps</li>
            <li>64-QAM，2/3 → 48 Mbps</li>
            <li>64-QAM，3/4 → 54 Mbps</li>
          </ul>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">13.3–13.5 OFDM PLCP、PMD 与特性</h3>
      <p className="text-gray-700 leading-relaxed">
        OFDM PLCP 帧由短训练序列（10×0.8μs）、长训练序列（2×3.2μs）和 SIGNAL 字段组成，用于同步和信道估计。5 GHz 频段提供更多非重叠信道（美国最多 23 个），无需与微波炉等设备共享，干扰更少。802.11j 是 802.11a 在日本 4.9/5 GHz 频段的版本。
      </p>
    </div>
  ),

  ch14: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch14.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch14.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第14章：802.11g：扩展速率物理层（ERP）</h2>
      <p className="text-gray-700 leading-relaxed">
        802.11g（2003年）在 2.4 GHz 频段实现了 OFDM，最高速率达 54 Mbps，同时保持对 802.11b 的<strong>向后兼容性</strong>。这是 802.11g 商业成功的关键，但兼容性也带来了严重的性能代价。
      </p>
      <h3 className="text-xl font-semibold text-gray-800">14.1 802.11g 组件</h3>
      <p className="text-gray-700 leading-relaxed">
        802.11g 定义了多种调制方式以实现兼容：<strong>ERP-OFDM</strong>（新设备间高速通信）、<strong>ERP-DSSS/CCK</strong>（与 802.11b 兼容）、<strong>ERP-PBCC</strong>（可选，更高效编码）。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">向后兼容的代价</h3>
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-800 font-semibold text-sm mb-2">混合模式性能损失</p>
        <p className="text-gray-700 text-sm">当 802.11b 设备存在于 802.11g 网络中时，AP 必须启用 <strong>保护机制（Protection Mode）</strong>：发送 OFDM 帧前先发送 CTS-to-Self 或 RTS/CTS（使用 802.11b 速率），让旧设备知道信道占用情况。这些保护帧的开销可使网络吞吐量下降 40%-50%。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">14.2–14.3 ERP PLCP 与 PMD</h3>
      <p className="text-gray-700 leading-relaxed">
        ERP 物理层支持长前导码（与802.11b兼容）和短前导码（更高效率）。实际部署中，802.11g 的实际吞吐量约为理论最大值的 50%-60%（约 20-25 Mbps TCP），受 MAC 层开销和帧间间隔限制。
      </p>
    </div>
  ),

  ch15: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch15.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch15.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第15章：前瞻 802.11n：MIMO-OFDM</h2>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-800 text-sm">注：本章写于 802.11n 标准化完成（2009年）之前，以"前瞻"视角介绍了当时两大竞争提案 WWiSE 和 TGnSync 的关键技术。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">MIMO 技术</h3>
      <p className="text-gray-700 leading-relaxed">
        <strong>MIMO（多输入多输出）</strong>技术通过同时使用多根天线发送和接收数据，充分利用多径传播——在传统无线通信中多径被视为有害的，但 MIMO 将其转化为优势，每条路径携带独立的数据流（空间复用）。
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white border border-purple-200 rounded-lg p-4">
          <h4 className="font-semibold text-purple-700 mb-2">空间复用</h4>
          <p className="text-sm text-gray-700">N 根天线可同时发送 N 个独立数据流，理论上将吞吐量提升 N 倍，无需增加额外带宽。802.11n 最多支持 4 条空间流。</p>
        </div>
        <div className="bg-white border border-green-200 rounded-lg p-4">
          <h4 className="font-semibold text-green-700 mb-2">空间分集</h4>
          <p className="text-sm text-gray-700">多天线接收同一信号的多个副本，通过 MRC（最大比合并）提升接收质量，扩大覆盖范围和抗衰落能力。</p>
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">802.11n 关键特性（标准化后）</h3>
      <ul className="list-disc pl-6 text-gray-700 space-y-1 text-sm">
        <li>最多 4 条空间流（4×4:4 MIMO）</li>
        <li>20 MHz 和 40 MHz 信道宽度</li>
        <li>短保护间隔（400 ns 替代 800 ns）</li>
        <li>HT（高吞吐量）PLCP 帧格式，向后兼容 802.11a/g</li>
        <li>最高 600 Mbps 理论速率（4 流 × 40 MHz × 64-QAM 5/6）</li>
        <li>支持 2.4 GHz 和 5 GHz 双频段</li>
      </ul>
    </div>
  ),

  ch16: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch16.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch16.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第16章：802.11 硬件</h2>
      <h3 className="text-xl font-semibold text-gray-800">16.1 802.11 接口的通用结构</h3>
      <p className="text-gray-700 leading-relaxed">
        典型的 802.11 网卡（NIC）由三个主要组件构成：<strong>MAC 芯片</strong>（实现协议状态机）、<strong>基带处理器</strong>（调制/解调、编码/解码）和<strong>RF 前端</strong>（上下变频、功放和低噪放）。这三部分可以集成在一颗或多颗芯片上。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">16.2 实现特定行为</h3>
      <p className="text-gray-700 leading-relaxed">
        不同厂商的 802.11 芯片在以下方面存在差异（影响性能和兼容性）：
      </p>
      <ul className="list-disc pl-6 text-gray-700 space-y-1 text-sm">
        <li><strong>速率自适应算法</strong>：如何根据信道质量选择最佳调制速率，各厂商实现不同</li>
        <li><strong>功率管理实现</strong>：省电模式的细节实现</li>
        <li><strong>扫描行为</strong>：主动/被动扫描的触发条件和频率</li>
        <li><strong>漫游触发阈值</strong>：何时决定切换到更强的 AP</li>
      </ul>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">16.3 解读规格表</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">规格参数</th>
            <th className="border border-gray-200 px-3 py-2">重要性</th>
            <th className="border border-gray-200 px-3 py-2">说明</th>
          </tr></thead>
          <tbody>
            {[
              ['发射功率 (dBm)', '高', '决定覆盖范围，受法规限制（通常≤20dBm）'],
              ['接收灵敏度 (dBm)', '高', '越低（负值绝对值越大）越好，决定能接收的最弱信号'],
              ['天线增益 (dBi)', '中', '全向天线约2-5dBi，方向性天线可达15+dBi'],
              ['支持标准', '高', '明确所支持的802.11变体'],
              ['最大数据率', '中', '理论值，实际吞吐量约为其50-60%'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  ),

  ch17: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch17.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch17.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第17章：在 Windows 上使用 802.11</h2>
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-amber-800 text-sm">本章原文针对 Windows XP 和 Windows 2000 时代，部分细节已过时，但核心概念（驱动架构、NDIS、WZC）仍有参考价值。</p>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">Windows 无线网络架构</h3>
      <p className="text-gray-700 leading-relaxed">
        Windows 通过 <strong>NDIS（网络驱动程序接口规范）</strong>为网络硬件提供统一的驱动框架。802.11 网卡驱动必须实现 NDIS 微型端口（Miniport）接口，向上层提供标准的 OID（对象标识符）查询和设置接口。
      </p>
      <p className="text-gray-700 leading-relaxed mt-2">
        Windows XP 引入了 <strong>WZC（无线零配置服务）</strong>，提供自动扫描、连接和漫游功能。WZC 通过 NDIS OID 与驱动交互，管理首选网络列表（PNL）。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">Windows 计算机认证</h3>
      <p className="text-gray-700 leading-relaxed">
        在企业环境中，可在用户登录前（机器阶段）就完成 802.1X 认证，使计算机策略（GPO）能够在用户登录前应用。这需要计算机证书或机器账号凭证。
      </p>
    </div>
  ),

  ch18: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch18.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch18.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第18章：在 macOS 上使用 802.11</h2>
      <h3 className="text-xl font-semibold text-gray-800">AirPort 系统</h3>
      <p className="text-gray-700 leading-relaxed">
        苹果 AirPort 系统是推动 802.11 大众化的重要力量之一。苹果于1999年发布 AirPort（基于802.11b）时，以极具竞争力的价格将无线网络带入消费市场，此前的竞品价格高达其数倍。
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <h4 className="font-semibold text-gray-800 mb-2">AirPort Extreme</h4>
          <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
            <li>支持 802.11a/b/g（第二版时）</li>
            <li>集成 802.1X 客户端</li>
            <li>macOS 的无线管理内置在 CoreWLAN 框架中</li>
            <li>Airport 工具提供图形化配置界面</li>
          </ul>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <h4 className="font-semibold text-gray-800 mb-2">macOS 上的 802.1X</h4>
          <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
            <li>支持 EAP-TLS（证书认证）</li>
            <li>支持 PEAP / EAP-TTLS（密码认证）</li>
            <li>Keychain 集成存储凭证</li>
            <li>Internet Connect 提供统一连接管理界面</li>
          </ul>
        </div>
      </div>
    </div>
  ),

  ch19: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch19.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch19.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第19章：在 Linux 上使用 802.11</h2>
      <h3 className="text-xl font-semibold text-gray-800">Linux 无线架构</h3>
      <p className="text-gray-700 leading-relaxed">
        Linux 通过 <strong>Linux 无线扩展（Wireless Extensions / iwconfig API）</strong>为用户空间提供统一的无线网卡配置接口。该框架允许用户空间工具（iwconfig、iwlist等）查询和控制驱动，而无需了解具体硬件细节。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">主要驱动与芯片组支持</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">驱动</th>
            <th className="border border-gray-200 px-3 py-2">支持芯片组</th>
            <th className="border border-gray-200 px-3 py-2">说明</th>
          </tr></thead>
          <tbody>
            {[
              ['orinoco / hermes', 'Agere (Lucent) Orinoco', '经典的 PCMCIA 网卡，内核主线驱动'],
              ['linux-wlan-ng', 'Intersil Prism', '早期的 DSSS 芯片，开源驱动项目'],
              ['MADwifi', 'Atheros AR5xxx', '支持 a/b/g，开源 Atheros 驱动（HAL问题）'],
              ['ath5k / ath9k', 'Atheros（新）', '完全开源的 Atheros 驱动，无二进制 HAL'],
              ['iwlwifi', 'Intel', 'Intel Wireless 系列的开源驱动'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">Linux 上的 802.1X：xsupplicant / wpa_supplicant</h3>
      <p className="text-gray-700 leading-relaxed">
        <code className="bg-gray-100 px-1 rounded text-sm">xsupplicant</code> 是早期 Linux 上的开源 EAP 请求方（Supplicant）。现代 Linux 系统普遍使用 <code className="bg-gray-100 px-1 rounded text-sm">wpa_supplicant</code>，支持 WPA/WPA2/WPA3 所有认证和加密模式，成为跨平台事实标准。
      </p>
    </div>
  ),

  ch20: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch20.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch20.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第20章：使用 802.11 接入点</h2>
      <h3 className="text-xl font-semibold text-gray-800">20.1 接入点的通用功能</h3>
      <p className="text-gray-700 leading-relaxed">
        接入点（AP）本质上是一台专用的桥接设备，在无线介质和有线以太网之间转发帧。现代 AP 通常还集成了 DHCP 服务器、NAT/路由、防火墙和 VPN 等功能。
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {[
          { title: '基本 AP 功能', items: ['SSID广播与隐藏', '多SSID/VLAN支持', 'WEP/WPA/WPA2加密', '802.1X认证集成', 'WDS（无线分发系统）'] },
          { title: '高级功能', items: ['QoS（802.11e/WMM）', '频谱管理（DFS/TPC）', 'Rogue AP检测', '负载均衡', 'PoE供电支持'] },
        ].map((group, i) => (
          <div key={i} className="bg-white border border-gray-200 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 mb-2">{group.title}</h4>
            <ul className="text-sm text-gray-700 space-y-1 list-disc pl-4">
              {group.items.map((item, j) => <li key={j}>{item}</li>)}
            </ul>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">20.2 以太网供电（PoE）</h3>
      <p className="text-gray-700 leading-relaxed">
        PoE（802.3af）允许通过以太网线缆为 AP 供电，无需在每个 AP 安装位置铺设独立电源线。这极大简化了企业级 AP 部署，特别是在天花板等难以布电的位置。PoE 交换机或 PoE 注入器提供最高 15.4W 功率（802.3af）。
      </p>
    </div>
  ),

  ch21: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch21.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch21.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第21章：逻辑无线网络架构</h2>
      <h3 className="text-xl font-semibold text-gray-800">21.1 评估逻辑架构</h3>
      <p className="text-gray-700 leading-relaxed">
        选择无线网络逻辑架构时，需要从以下维度评估：<strong>移动性</strong>（用户在网络中的漫游需求）、<strong>安全性</strong>（认证和加密要求）、<strong>性能</strong>（吞吐量和延迟）、<strong>骨干工程</strong>（VLAN 设计和 IP 寻址）。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">21.2 拓扑示例</h3>
      <div className="space-y-4">
        {[
          { title: '拓扑1：单一子网整体网络', desc: '所有 AP 和客户端在同一平面二层网络，配置最简单，但不适合大规模部署（广播域过大，漫游时 IP 地址改变）。' },
          { title: '拓扑2："ET 打电话回家"', desc: '客户端通过 VPN 隧道连接中心服务器，提供与位置无关的安全访问，适合公共 Wi-Fi 环境，但延迟较高。' },
          { title: '拓扑3：动态 VLAN 分配', desc: 'RADIUS 服务器根据用户身份返回 VLAN 属性，AP 据此将客户端分配到对应 VLAN，实现基于身份的网络隔离，复杂度中等。' },
          { title: '拓扑4：虚拟接入点（Multi-SSID）', desc: '单个 AP 广播多个 SSID，每个 SSID 绑定到不同 VLAN，支持同一物理基础设施服务不同策略的用户群（如员工和访客）。' },
        ].map((topo, i) => (
          <div key={i} className="bg-white border border-indigo-100 rounded-lg p-4 shadow-sm">
            <h4 className="font-semibold text-indigo-700 mb-1">{topo.title}</h4>
            <p className="text-sm text-gray-700">{topo.desc}</p>
          </div>
        ))}
      </div>
    </div>
  ),

  ch22: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch22.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch22.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第22章：安全架构</h2>
      <h3 className="text-xl font-semibold text-gray-800">22.1 无线局域网安全问题定义</h3>
      <p className="text-gray-700 leading-relaxed">全面的无线安全架构需覆盖以下威胁：</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {[
          { threat: '未授权访问', sol: '认证（802.1X/EAP）+ 关联控制' },
          { threat: '窃听（嗅探）', sol: '强加密（WPA2-CCMP/AES）' },
          { threat: '流量注入/篡改', sol: '消息完整性（MIC/CCMP）' },
          { threat: '拒绝服务（DoS）', sol: '管理帧保护（802.11w）' },
          { threat: '流氓接入点', sol: '无线 IDS/IPS + 802.1X 双向认证' },
          { threat: '流氓客户端', sol: 'NAC + 终端健康检查' },
        ].map((item, i) => (
          <div key={i} className="flex gap-3 bg-white border border-gray-200 rounded-lg p-3">
            <div className="text-red-500 shrink-0">⚠️</div>
            <div>
              <p className="font-semibold text-gray-800 text-sm">{item.threat}</p>
              <p className="text-xs text-green-700 mt-0.5">✓ {item.sol}</p>
            </div>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">22.2–22.3 认证与加密选择</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">场景</th>
            <th className="border border-gray-200 px-3 py-2">推荐认证</th>
            <th className="border border-gray-200 px-3 py-2">推荐加密</th>
          </tr></thead>
          <tbody>
            {[
              ['家庭/小型办公室', 'WPA2-Personal（预共享密钥）', 'AES-CCMP'],
              ['企业标准', '802.1X + EAP-TLS 或 PEAP', 'AES-CCMP (WPA2-Enterprise)'],
              ['高安全企业', '802.1X + EAP-TLS（双向证书）', 'CCMP + 802.11w（PMF）'],
              ['公共热点', '强制门户 + VPN', 'VPN 隧道加密'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">22.5 流氓接入点</h3>
      <p className="text-gray-700 leading-relaxed">
        流氓 AP（Rogue AP）是指未经授权接入企业有线网络的无线接入点，可能由员工出于方便（无意的安全漏洞）或攻击者（有意的入侵桥梁）设置。检测手段包括：无线扫描（通过有线端检测未知 AP 的 BSSID）、802.1X 强制认证（有线端口拒绝未认证设备）。
      </p>
    </div>
  ),

  ch23: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch23.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch23.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第23章：站点规划与项目管理</h2>
      <h3 className="text-xl font-semibold text-gray-800">23.1 项目规划与需求</h3>
      <p className="text-gray-700 leading-relaxed">
        无线网络部署项目的成败很大程度上取决于前期规划的质量。需要明确的关键需求：覆盖区域、用户密度与流量预期、应用类型（数据/语音/视频）、漫游需求、安全策略。
      </p>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">23.2 网络需求与物理层选择</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { band: '2.4 GHz (802.11b/g/n)', pros: '穿墙能力强，覆盖范围大', cons: '仅3个非重叠信道，干扰严重（微波炉、蓝牙）' },
          { band: '5 GHz (802.11a/n/ac)', pros: '20+个非重叠信道，干扰少，支持更高速率', cons: '穿墙能力弱，覆盖范围小' },
          { band: '双频 (2.4+5 GHz)', pros: '兼顾覆盖和容量，灵活分配负载', cons: '需要双频 AP，成本较高' },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <h4 className="font-semibold text-gray-800 text-sm mb-2">{item.band}</h4>
            <p className="text-xs text-green-700 mb-1">✓ {item.pros}</p>
            <p className="text-xs text-red-600">✗ {item.cons}</p>
          </div>
        ))}
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">23.3 无线站点勘测（Site Survey）</h3>
      <p className="text-gray-700 leading-relaxed">
        站点勘测是确定 AP 最优部署位置的关键步骤：
      </p>
      <ol className="list-decimal pl-6 text-gray-700 space-y-2 text-sm">
        <li><strong>获取建筑平面图</strong>：标记承重墙、电梯井、金属障碍物等 RF 阻挡源。</li>
        <li><strong>识别潜在干扰源</strong>：定位微波炉、无绳电话、已有无线设备等。</li>
        <li><strong>测量 RF 传播特性</strong>：使用临时 AP 和信号强度测量工具（如 Ekahau）记录各位置的信号强度和 SNR。</li>
        <li><strong>确定覆盖需求</strong>：根据应用类型确定最低可接受的信号强度（一般数据：-70dBm；语音：-67dBm）。</li>
        <li><strong>规划 AP 位置和信道分配</strong>：相邻 AP 使用非重叠信道，蜂窝式覆盖，重叠约15-20%用于无缝漫游。</li>
      </ol>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">23.4 天线选型</h3>
      <p className="text-gray-700 leading-relaxed">
        不同场景需要不同类型的天线：全向天线适合开放空间（办公区）；定向天线（扇形、扁平板）适合走廊、仓库等细长区域；高增益定向天线（八木、抛物面）用于楼间点对点链路。
      </p>
    </div>
  ),

  ch24: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch24.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch24.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第24章：802.11 网络分析</h2>
      <h3 className="text-xl font-semibold text-gray-800">24.1 网络分析器工具</h3>
      <p className="text-gray-700 leading-relaxed">
        网络分析器（抓包工具）是诊断 802.11 问题的基础工具，可以捕获并解析 802.11 帧（包括管理帧、控制帧和数据帧），揭示协议层面的问题。
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">工具</th>
            <th className="border border-gray-200 px-3 py-2">类型</th>
            <th className="border border-gray-200 px-3 py-2">特点</th>
          </tr></thead>
          <tbody>
            {[
              ['Wireshark（原 Ethereal）', '开源', '最强大的跨平台分析器，支持802.11帧完整解析（需monitor模式）'],
              ['tcpdump + radiotap', '开源命令行', 'Linux/macOS的基础抓包工具，支持BPF过滤表达式'],
              ['AirMagnet', '商业', '专用无线分析套件，包含站点勘测和频谱分析'],
              ['Kismet', '开源', '无线IDS和被动扫描工具，支持多种适配器'],
              ['AirSnort', '开源安全工具', '专用于分析WEP弱点的工具（历史意义）'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">24.2 802.11 网络分析检查清单</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {[
          { category: '关联问题', checks: ['Probe Request/Response 是否正常？', '认证帧是否被拒绝？', 'Association Request 被拒绝的状态码？'] },
          { category: '性能问题', checks: ['重传率是否过高（>10%）？', '帧速率是否意外降低？', 'ACK 响应时间是否异常？'] },
          { category: '干扰问题', checks: ['CRC 错误率高？', '信道繁忙时间占比？', '邻居 AP 信道是否重叠？'] },
          { category: '安全问题', checks: ['是否有非法去认证帧？', 'RSN 信息元素协商是否正确？', '四次握手是否完整？'] },
        ].map((item, i) => (
          <div key={i} className="bg-white border border-gray-200 rounded-lg p-4">
            <h4 className="font-semibold text-gray-800 text-sm mb-2">{item.category}</h4>
            <ul className="text-xs text-gray-700 space-y-1 list-disc pl-4">
              {item.checks.map((c, j) => <li key={j}>{c}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </div>
  ),

  ch25: (
    <div className="space-y-6">
      <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg">
        <p className="text-sm text-indigo-700 font-medium">原文来源</p>
        <a href="https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch25.html" className="text-indigo-600 hover:underline text-sm break-all" target="_blank" rel="noopener noreferrer">
          https://www.oreilly.com/library/view/802-11-wireless-networks/0596100523/ch25.html
        </a>
      </div>
      <h2 className="text-2xl font-bold text-gray-900">第25章：802.11 性能调优</h2>
      <h3 className="text-xl font-semibold text-gray-800">性能调优参数总览</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse border border-gray-200 rounded-lg">
          <thead><tr className="bg-gray-100">
            <th className="border border-gray-200 px-3 py-2">参数</th>
            <th className="border border-gray-200 px-3 py-2">默认值</th>
            <th className="border border-gray-200 px-3 py-2">调优方向</th>
            <th className="border border-gray-200 px-3 py-2">说明</th>
          </tr></thead>
          <tbody>
            {[
              ['RTS 阈值', '2347（关闭）', '环境嘈杂时降低（如500）', '帧大于此阈值时触发RTS/CTS，减少隐藏节点碰撞'],
              ['分片阈值', '2346（关闭）', '嘈杂环境降低（如1000）', '大帧拆分，降低每片重传代价'],
              ['Beacon 间隔', '100ms（TU）', '通常无需调整', '过长影响省电和新设备发现速度'],
              ['最低速率', '1/2 Mbps', '提高到6/11 Mbps', '剔除边缘低速设备，提升网络整体容量'],
              ['DTIM 周期', '1（每Beacon）', '省电设备多时增大', '控制组播/广播帧发送频率'],
              ['信道选择', '自动或1/6/11', '使用信道扫描工具选择干扰最小信道', '避免与邻居AP信道重叠'],
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                {row.map((cell, j) => <td key={j} className="border border-gray-200 px-3 py-2 text-gray-700">{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h3 className="text-xl font-semibold text-gray-800 mt-4">性能调优策略</h3>
      <div className="space-y-3">
        {[
          { title: '提高最低速率（Rate Floor）', desc: '设置最低连接速率（如 802.11g 网络设为 6 Mbps），避免低速设备（边缘站点）长时间占用信道，提升整体网络容量。代价是覆盖边缘用户断线。' },
          { title: '启用 RTS/CTS（高密度环境）', desc: '在用户密集或障碍物多的环境中，降低 RTS 阈值（如 500 字节），启用 RTS/CTS 握手。虽然增加了少量开销，但可显著降低碰撞率，实际提升吞吐量。' },
          { title: '合理分片', desc: '在高误码率（嘈杂）环境中，开启分片将大帧拆分，降低每次重传的代价。但分片会引入额外帧头开销，需要通过测量确定最优阈值。' },
          { title: '信道规划与 AP 密度', desc: '正确的信道规划比任何 AP 参数调优效果更显著。高密度部署中，适当降低 AP 发射功率（减小每个 AP 的覆盖区），可允许更多 AP 复用同一信道而不互相干扰。' },
        ].map((item, i) => (
          <div key={i} className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-lg">
            <h4 className="font-semibold text-blue-700 mb-1">{item.title}</h4>
            <p className="text-sm text-gray-700">{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  ),

  summary: (
    <div className="space-y-8">
      <div className="bg-gradient-to-br from-indigo-900 to-purple-900 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">第一性原理总结</h2>
        <p className="text-indigo-200 text-sm">回归无线网络设计的本质假设，从根本性约束出发推导整个技术体系</p>
      </div>

      <div className="space-y-6">
        <h3 className="text-xl font-bold text-gray-900">一、最根本的物理约束</h3>
        <div className="bg-gray-900 text-green-400 rounded-xl p-6 font-mono text-sm leading-relaxed">
          <p className="text-yellow-400 font-bold mb-3">// 第一性原理：无线信道的本质</p>
          <p>1. 电磁波 = 共享介质（所有人都在同一频段中发送）</p>
          <p>2. 信号强度 ∝ 1/距离²（自由空间路径损耗）</p>
          <p>3. 发送方无法同时侦听（半双工）→ 无法检测碰撞</p>
          <p>4. 多径传播 = 信号自我干扰 + 延迟扩展</p>
          <p>5. RF边界无法精确控制 → 安全边界本质上不存在</p>
        </div>
        <p className="text-gray-700 leading-relaxed">
          整个 802.11 协议栈的所有复杂性，都是为了在这五条物理约束下，尽可能高效、可靠、安全地传输数据。没有一项设计决策是任意的。
        </p>

        <h3 className="text-xl font-bold text-gray-900 mt-6">二、从物理约束推导核心设计决策</h3>
        <div className="space-y-4">
          {[
            {
              constraint: '共享介质 + 半双工',
              derivation: '必须有多路访问控制协议',
              solution: 'CSMA/CA（DCF）：先听后发，随机退避，而非 CSMA/CD',
              color: 'blue',
            },
            {
              constraint: '无法感知远端节点（隐藏节点）',
              derivation: '仅靠信道侦听无法完全避免碰撞',
              solution: 'RTS/CTS 握手：用虚拟载波侦听（NAV）通知范围内所有节点',
              color: 'green',
            },
            {
              constraint: '高误码率（RF 链路质量差）',
              derivation: '上层 TCP 超时重传代价极高',
              solution: '802.11 MAC 层内建 ARQ（自动重传请求）+ 逐帧 ACK',
              color: 'yellow',
            },
            {
              constraint: '多径时延扩展导致码间干扰',
              derivation: '单载波高速传输受限于时延扩展',
              solution: 'OFDM：多个低速子载波并行，符号时间远大于时延扩展；循环前缀彻底消除 ISI',
              color: 'purple',
            },
            {
              constraint: 'RF 边界不可控（信号泄漏）',
              derivation: '物理层隔离失效，传统有线安全假设不成立',
              solution: '必须在链路层加密（WEP → TKIP → CCMP/AES），认证下沉到链路层（802.1X）',
              color: 'red',
            },
            {
              constraint: '电池设备功耗有限',
              derivation: '持续侦听信道耗尽电池',
              solution: '省电模式（PSM）：协商休眠周期，AP 缓冲数据，Beacon TIM 唤醒',
              color: 'orange',
            },
          ].map((item, i) => {
            const colorMap: Record<string, string> = {
              blue: 'border-blue-400 bg-blue-50',
              green: 'border-green-400 bg-green-50',
              yellow: 'border-yellow-400 bg-yellow-50',
              purple: 'border-purple-400 bg-purple-50',
              red: 'border-red-400 bg-red-50',
              orange: 'border-orange-400 bg-orange-50',
            };
            const titleColor: Record<string, string> = {
              blue: 'text-blue-700', green: 'text-green-700', yellow: 'text-yellow-700',
              purple: 'text-purple-700', red: 'text-red-700', orange: 'text-orange-700',
            };
            return (
              <div key={i} className={`border-l-4 rounded-r-xl p-5 ${colorMap[item.color]}`}>
                <div className="flex flex-col gap-2">
                  <div>
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">物理约束</span>
                    <p className={`font-semibold ${titleColor[item.color]}`}>{item.constraint}</p>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">推导结论</span>
                    <p className="text-gray-700 text-sm">{item.derivation}</p>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">设计解法</span>
                    <p className="text-gray-700 text-sm font-medium">{item.solution}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <h3 className="text-xl font-bold text-gray-900 mt-6">三、安全演进的第一性原理</h3>
        <p className="text-gray-700 leading-relaxed">
          WEP 失败的根本原因不是工程缺陷，而是<strong>设计假设错误</strong>——它假设 IV 空间足够大、RC4 密钥调度是安全的、CRC-32 足够防篡改。这三个假设全部被证伪。
        </p>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-5 text-sm text-gray-700">
          <p className="font-bold text-gray-900 mb-3">正确的密码学第一原则告诉我们：</p>
          <ul className="space-y-2 list-disc pl-5">
            <li><strong>机密性</strong>需要语义安全的加密（AES-CTR），而非有漏洞的 RC4</li>
            <li><strong>完整性</strong>需要密码学 MAC（HMAC/CMAC），而非线性校验码（CRC）</li>
            <li><strong>新鲜性（防重放）</strong>需要单调递增的序列号（CCMP PN）</li>
            <li><strong>认证</strong>需要双向验证（EAP-TLS），而非单向</li>
            <li><strong>密钥管理</strong>需要自动化（四次握手），而非手动静态配置</li>
          </ul>
          <p className="mt-3 text-indigo-700 font-medium">CCMP 正是依照这些原则，在一个算法中同时实现了以上所有保证。</p>
        </div>

        <h3 className="text-xl font-bold text-gray-900 mt-6">四、性能调优的第一性原理</h3>
        <p className="text-gray-700 leading-relaxed">
          802.11 网络的所有性能问题，最终都可以归结为两个根本矛盾：
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h4 className="font-bold text-gray-900 mb-3">矛盾1：覆盖 vs. 容量</h4>
            <p className="text-sm text-gray-700">增大覆盖范围 → 边缘设备使用低速率 → 占用信道时间更长 → 整体网络容量下降。解法：蜂窝化部署（小区），降低功率，提高最低速率门槛。</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h4 className="font-bold text-gray-900 mb-3">矛盾2：可靠性 vs. 效率</h4>
            <p className="text-sm text-gray-700">RTS/CTS、ACK、保护机制、分片——每一项可靠性增强措施都引入额外开销。调优本质是在特定环境中找到可靠性和效率的最优平衡点，需要测量而非猜测。</p>
          </div>
        </div>

        <h3 className="text-xl font-bold text-gray-900 mt-6">五、对无线网络未来的第一性预判</h3>
        <p className="text-gray-700 leading-relaxed">
          从第一性原理出发，无线网络技术发展的方向是确定的：
        </p>
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-5">
          <ul className="space-y-3 text-gray-700 text-sm">
            <li>📡 <strong>更多天线（MIMO 演进）</strong>：空间维度是最后一个可利用的物理自由度，从 2×2 到 8×8，持续提升空间复用增益（802.11ax/be）。</li>
            <li>🔧 <strong>更宽信道（80/160/320 MHz）</strong>：更宽带宽直接倍增吞吐量，5 GHz / 6 GHz 频段释放空间（802.11ax Wi-Fi 6E 引入 6 GHz）。</li>
            <li>🤝 <strong>多用户 MIMO（MU-MIMO）与 OFDMA</strong>：AP 同时服务多个用户，而非串行，从根本上提升密集场景效率。</li>
            <li>🔐 <strong>安全强制化</strong>：WPA3 强制前向保密（SAE）和 PMF，消除最后的 WPA2 弱点。</li>
            <li>⚡ <strong>确定性低延迟</strong>：Wi-Fi 7（802.11be）引入多链路操作（MLO）和 4K-QAM，面向 AR/VR/工业物联网场景。</li>
          </ul>
        </div>

        <div className="bg-indigo-900 text-white rounded-2xl p-6 mt-6">
          <h3 className="text-xl font-bold mb-3">最终结论</h3>
          <p className="text-indigo-100 leading-relaxed">
            《802.11 无线网络权威指南》所呈现的，是人类在面对一组不可改变的物理约束（电磁波的传播规律）时，如何通过层层抽象和精巧设计，构建出可靠、高效、安全的通信系统的完整过程。
          </p>
          <p className="text-indigo-200 leading-relaxed mt-3">
            理解 802.11 的最好方式，不是记忆具体参数和帧格式，而是理解每一个设计决策背后的物理约束和工程权衡。当你真正理解了为什么需要 CSMA/CA 而非 CSMA/CD，为什么 WEP 必然失败，为什么 OFDM 能解决多径问题——你就掌握了这门技术的本质，无论协议如何演进，这些第一原则始终适用。
          </p>
        </div>
      </div>
    </div>
  ),
};

export default function App() {
  const [activeChapter, setActiveChapter] = useState('preface');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);
  const mainRef = useRef<HTMLDivElement>(null);

  const currentIndex = chapters.findIndex(c => c.id === activeChapter);

  const goToChapter = useCallback((id: string) => {
    setActiveChapter(id);
    setSidebarOpen(false);
    if (mainRef.current) {
      mainRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    setScrollProgress(0);
  }, []);

  const goPrev = useCallback(() => {
    if (currentIndex > 0) goToChapter(chapters[currentIndex - 1].id);
  }, [currentIndex, goToChapter]);

  const goNext = useCallback(() => {
    if (currentIndex < chapters.length - 1) goToChapter(chapters[currentIndex + 1].id);
  }, [currentIndex, goToChapter]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') goPrev();
      if (e.key === 'ArrowRight') goNext();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [goPrev, goNext]);

  useEffect(() => {
    const main = mainRef.current;
    if (!main) return;
    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = main;
      const progress = scrollHeight - clientHeight > 0
        ? (scrollTop / (scrollHeight - clientHeight)) * 100
        : 0;
      setScrollProgress(progress);
    };
    main.addEventListener('scroll', handleScroll);
    return () => main.removeEventListener('scroll', handleScroll);
  }, []);

  // Group chapters
  const groups: Record<string, typeof chapters> = {};
  chapters.forEach(ch => {
    if (!groups[ch.group]) groups[ch.group] = [];
    groups[ch.group].push(ch);
  });

  const currentChapter = chapters.find(c => c.id === activeChapter);

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Progress bar */}
      <div className="fixed top-0 left-0 right-0 h-1 z-50 bg-gray-200">
        <div
          className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-150"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed top-0 left-0 h-full z-40 bg-gray-900 text-white
        w-72 flex flex-col transition-transform duration-300 ease-in-out
        lg:static lg:translate-x-0 lg:flex-shrink-0
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Sidebar header */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-gray-700 shrink-0">
          <div className="min-w-0">
            <p className="text-xs text-indigo-400 font-medium truncate">802.11 Wireless Networks</p>
            <p className="text-sm font-bold text-white leading-tight">The Definitive Guide</p>
            <p className="text-xs text-gray-400 mt-0.5">Matthew Gast · O'Reilly · 2005</p>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-gray-400 hover:text-white p-1 shrink-0 ml-2"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2}>
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {Object.entries(groups).map(([group, chs]) => (
            <div key={group} className="mb-3">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-1.5">{group}</p>
              {chs.map(ch => (
                <button
                  key={ch.id}
                  onClick={() => goToChapter(ch.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors mb-0.5 ${
                    activeChapter === ch.id
                      ? 'bg-indigo-600 text-white font-medium'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  {ch.title}
                </button>
              ))}
            </div>
          ))}
        </nav>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Top bar */}
        <header className="flex items-center gap-3 px-4 py-3 bg-white border-b border-gray-200 shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-gray-600 hover:text-gray-900 p-1"
          >
            <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2}>
              <path d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-800 truncate">{currentChapter?.title}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-gray-500 hidden sm:block">
              {currentIndex + 1} / {chapters.length}
            </span>
            <button
              onClick={goPrev}
              disabled={currentIndex === 0}
              className="p-1.5 rounded-lg text-gray-500 hover:text-gray-900 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="上一章 (←)"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
            <button
              onClick={goNext}
              disabled={currentIndex === chapters.length - 1}
              className="p-1.5 rounded-lg text-gray-500 hover:text-gray-900 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="下一章 (→)"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>
          </div>
        </header>

        {/* Content */}
        <main ref={mainRef} className="flex-1 overflow-y-auto">
          <div ref={contentRef} className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
            {chapters_content[activeChapter]}

            {/* Navigation buttons at bottom */}
            <div className="flex gap-3 mt-12 pt-6 border-t border-gray-200">
              {currentIndex > 0 && (
                <button
                  onClick={goPrev}
                  className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-gray-700 hover:bg-gray-50 hover:border-indigo-300 transition-colors text-sm flex-1 min-w-0"
                >
                  <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" strokeWidth={2}>
                    <path d="M15 18l-6-6 6-6" />
                  </svg>
                  <span className="truncate">{chapters[currentIndex - 1].title}</span>
                </button>
              )}
              {currentIndex < chapters.length - 1 && (
                <button
                  onClick={goNext}
                  className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors text-sm flex-1 justify-end min-w-0 ml-auto"
                >
                  <span className="truncate">{chapters[currentIndex + 1].title}</span>
                  <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" strokeWidth={2}>
                    <path d="M9 18l6-6-6-6" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
